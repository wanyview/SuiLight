# .github/ GitHub配置目录

此目录包含GitHub相关的配置文件，包括CI/CD工作流、Issue模板、Pull Request模板等。

## 目录结构

```
.github/
├── workflows/                  # GitHub Actions工作流
│   ├── ci.yml                 # 持续集成
│   ├── cd.yml                 # 持续部署
│   ├── test.yml               # 测试工作流
│   ├── lint.yml               # 代码检查
│   └── security.yml           # 安全扫描
├── ISSUE_TEMPLATE/            # Issue模板
│   ├── bug_report.yml         # Bug报告模板
│   ├── feature_request.yml    # 功能请求模板
│   └── question.yml           # 问题咨询模板
├── PULL_REQUEST_TEMPLATE.md   # Pull Request模板
├── CODEOWNERS                 # 代码所有者
├── FUNDING.yml                # 赞助信息
├── SECURITY.md                # 安全政策
└── CONTRIBUTING.md            # 贡献指南
```

## CI/CD工作流示例

### CI工作流 (.github/workflows/ci.yml)
```yaml
name: Continuous Integration

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    strategy:
      matrix:
        node-version: [16.x, 18.x, 20.x]
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        
      - name: Setup Node.js ${{ matrix.node-version }}
        uses: actions/setup-node@v4
        with:
          node-version: ${{ matrix.node-version }}
          cache: 'npm'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Run linter
        run: npm run lint
        
      - name: Run type check
        run: npm run type-check
        
      - name: Run unit tests
        run: npm run test:unit
        
      - name: Run integration tests
        run: npm run test:integration
        
      - name: Upload coverage reports
        uses: codecov/codecov-action@v3
        with:
          token: ${{ secrets.CODECOV_TOKEN }}
          
  build:
    runs-on: ubuntu-latest
    needs: test
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18.x'
          cache: 'npm'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Build project
        run: npm run build
        
      - name: Upload build artifacts
        uses: actions/upload-artifact@v4
        with:
          name: build-files
          path: dist/
          
  security:
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        
      - name: Run security audit
        run: npm audit --audit-level moderate
        
      - name: Run Snyk security scan
        uses: snyk/actions/node@master
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
```

### CD工作流 (.github/workflows/cd.yml)
```yaml
name: Continuous Deployment

on:
  push:
    branches: [ main ]
    tags: [ 'v*' ]

jobs:
  deploy-staging:
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/develop'
    environment: staging
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18.x'
          cache: 'npm'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Build project
        run: npm run build
        
      - name: Deploy to staging
        run: |
          echo "Deploying to staging environment..."
          # 部署脚本
          
  deploy-production:
    runs-on: ubuntu-latest
    if: startsWith(github.ref, 'refs/tags/v')
    environment: production
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18.x'
          cache: 'npm'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Build project
        run: npm run build
        
      - name: Create release
        uses: softprops/action-gh-release@v1
        with:
          tag_name: ${{ github.ref_name }}
          name: Release ${{ github.ref_name }}
          body: |
            ## Changes in this release
            
            - Feature 1
            - Feature 2
            - Bug fixes
          draft: false
          prerelease: false
          
      - name: Deploy to production
        run: |
          echo "Deploying to production environment..."
          # 部署脚本
```

## Issue模板示例

### Bug报告模板 (.github/ISSUE_TEMPLATE/bug_report.yml)
```yaml
name: Bug Report
description: 报告一个Bug来帮助我们改进
title: "[Bug]: "
labels: ["bug", "triage"]
assignees: []

body:
  - type: markdown
    attributes:
      value: |
        Thanks for taking the time to fill out this bug report!

  - type: input
    id: bug-description
    attributes:
      label: Bug描述
      description: 简洁明了地描述这个Bug
      placeholder: 例如：点击按钮时应用崩溃
    validations:
      required: true

  - type: textarea
    id: steps-to-reproduce
    attributes:
      label: 重现步骤
      description: 详细描述如何重现这个Bug
      placeholder: |
        1. 打开...
        2. 点击...
        3. 滚动到...
        4. 看到错误
    validations:
      expected: true

  - type: textarea
    id: expected-behavior
    attributes:
      label: 预期行为
      description: 描述你预期会发生什么
      placeholder: 我期望...

  - type: textarea
    id: actual-behavior
    attributes:
      label: 实际行为
      description: 描述实际发生了什么
      placeholder: 实际上...

  - type: dropdown
    id: severity
    attributes:
      label: 严重程度
      description: 这个Bug的严重程度
      options:
        - "轻微 - 轻微影响用户体验"
        - "中等 - 明显影响用户体验"
        - "严重 - 严重影响使用"
        - "致命 - 应用无法使用"

  - type: dropdown
    id: environment
    attributes:
      label: 环境信息
      description: 选择你的环境
      options:
        - "桌面版 - Chrome"
        - "桌面版 - Firefox"
        - "桌面版 - Safari"
        - "移动版 - iOS"
        - "移动版 - Android"

  - type: input
    id: version
    attributes:
      label: 应用版本
      description: 你使用的应用版本
      placeholder: 例如：v1.2.3

  - type: textarea
    id: screenshots
    attributes:
      label: 截图
      description: 如果适用，请添加截图
      placeholder: |
        ![description](url)

  - type: textarea
    id: additional-context
    attributes:
      label: 其他信息
      description: 其他任何有用的信息
      placeholder: |

  - type: checkboxes
    id: terms
    attributes:
      label: 确认
      description: 
      options:
        - label: 我已经搜索了现有的Issue，没有找到相关的
          required: true
        - label: 我已经提供了重现步骤
          required: true
        - label: 我理解这是一个志愿者项目
          required: true
```

### 功能请求模板 (.github/ISSUE_TEMPLATE/feature_request.yml)
```yaml
name: Feature Request
description: 为这个项目建议一个想法
title: "[Feature]: "
labels: ["enhancement", "triage"]
assignees: []

body:
  - type: markdown
    attributes:
      value: |
        Thanks for suggesting a new feature!

  - type: input
    id: feature-summary
    attributes:
      label: 功能概要
      description: 简要描述你想要的特性
      placeholder: 例如：添加暗色模式支持
    validations:
      required: true

  - type: textarea
    id: problem-motivated
    attributes:
      label: 问题动机
      description: 这个功能解决了什么问题？
      placeholder: 描述你遇到的问题或痛点

  - type: textarea
    id: proposed-solution
    attributes:
      label: 建议的解决方案
      description: 你希望这个功能如何工作？
      placeholder: 描述你期望的解决方案

  - type: textarea
    id: alternatives
    attributes:
      label: 替代方案
      description: 你考虑过其他解决方案吗？
      placeholder: 描述其他可能的解决方案

  - type: textarea
    id: additional-context
    attributes:
      label: 其他信息
      description: 任何其他相关信息、截图等
      placeholder: |

  - type: checkboxes
    id: contribution-willing
    attributes:
      label: 贡献意愿
      options:
        - label: 我愿意为这个功能贡献代码
        - label: 我愿意帮助测试这个功能
```

## Pull Request模板 (.github/PULL_REQUEST_TEMPLATE.md)
```markdown
## 📝 Pull Request 描述

简要描述这个PR的目的和内容。

## 🔍 类型

请选择合适的标签：
- [ ] 🐛 Bug修复 (不破坏现有功能的修复)
- [ ] ✨ 新功能 (不破坏现有功能的新特性)
- [ ] 💥 破坏性变更 (会导致现有功能无法正常工作的修复或特性)
- [ ] 📚 文档更新 (仅文档变更)
- [ ] 🎨 样式改进 (不影响代码含义的变更)
- [ ] ♻️ 代码重构 (既不修复bug也不添加特性的代码变更)
- [ ] ⚡ 性能改进
- [ ] ✅ 测试添加或改进
- [ ] 🔧 构建工具或辅助工具的变动

## 🧪 测试

- [ ] 我已经添加了覆盖新代码的测试
- [ ] 所有新的和现有的测试都通过了
- [ ] 我已经手动测试了这些变更

## 📋 清单

请确认以下各项：

- [ ] 我的代码遵循了项目的代码风格指南
- [ ] 我已经进行了自我代码审查
- [ ] 我的变更生成了新的警告
- [ ] 我已经添加了必要的注释，特别是在复杂区域
- [ ] 我已经对相应的文档进行了变更
- [ ] 我的变更没有引入新的依赖关系
- [ ] 我已经正确地设置了分支并合并到目标分支

## 🖼️ 截图（如果适用）

| 变更前 | 变更后 |
|--------|--------|
| 截图1 | 截图2 |

## 🔗 相关Issue

修复 # (issue编号)

## 📝 额外说明

任何其他需要说明的信息。
```

## 代码所有者 (.github/CODEOWNERS)
```bash
# 全局代码所有者
* @maintainer-username

# 前端代码
/src/ @frontend-team
/public/ @frontend-team

# 后端代码
/server/ @backend-team
/api/ @backend-team

# 文档
/docs/ @docs-team
*.md @docs-team

# 配置文件
package.json @maintainer-username
tsconfig.json @maintainer-username
.eslintrc.js @maintainer-username
```

## 赞助信息 (.github/FUNDING.yml)
```yaml
github: # GitHub赞助用户名
patreon: # Patreon用户名
open_collective: # Open Collective用户名
ko_fi: # Ko-fi用户名
tidelift: # Tidelift包名
community_bridge: # Community Bridge项目名
liberapay: # Liberapay用户名
issuehunt: # IssueHunt用户名
otechie: # Otechie用户名
custom: # 自定义链接
```

## 安全政策 (.github/SECURITY.md)
```markdown
# Security Policy

## 支持的版本

我们目前支持以下版本的安全更新：

| 版本 | 支持          |
| ------- | ------------------ |
| 2.1.x   | :white_check_mark: |
| 2.0.x   | :white_check_mark: |
| 1.x     | :x:                |

## 报告漏洞

请不要在公共Issue中报告安全漏洞。

请通过以下方式报告安全问题：

1. 发送邮件到 security@example.com
2. 使用我们的私有漏洞报告系统

我们将在24小时内确认收到报告，并在72小时内提供详细的响应。

## 响应流程

1. 确认收到报告
2. 评估影响和严重程度
3. 制定修复计划
4. 开发修复补丁
5. 测试补丁
6. 发布安全更新
7. 公开披露（如果有的话）
```

## 贡献指南 (.github/CONTRIBUTING.md)
```markdown
# 贡献指南

首先，非常感谢你对项目的兴趣！我们欢迎所有形式的贡献。

## 如何贡献

### 报告Bug
请使用Bug报告模板，并提供详细信息。

### 提议新功能
请使用功能请求模板，清楚地描述你的想法。

### 提交Pull Request
1. Fork这个仓库
2. 创建你的特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交你的更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启一个Pull Request

## 开发环境设置

### 前置要求
- Node.js 16+
- npm 8+

### 安装步骤
1. 克隆仓库
2. 安装依赖：`npm install`
3. 启动开发服务器：`npm run dev`

## 代码规范

### JavaScript/TypeScript
- 使用有意义的变量名
- 添加JSDoc注释
- 遵循ESLint规则

### 提交信息格式
使用语义化的提交信息：
- `feat:` 新功能
- `fix:` 修复
- `docs:` 文档
- `style:` 格式
- `refactor:` 重构
- `test:` 测试
- `chore:` 构建过程或辅助工具

### 测试
- 编写单元测试
- 确保所有测试通过
- 保持测试覆盖率

## 社区行为准则

我们致力于提供一个友好、包容的社区环境。请：

- 保持友善和尊重
- 建设性地提供反馈
- 尊重不同的观点和经验
- 专注于对社区最有利的事情

## 许可证

通过贡献，你同意你的贡献将在MIT许可证下许可。
```

## 工作流最佳实践

### 安全考虑
- 使用secrets存储敏感信息
- 定期更新依赖和Actions
- 限制工作流的权限
- 使用环境的secret

### 性能优化
- 缓存依赖和构建结果
- 并行运行独立作业
- 避免不必要的步骤
- 使用矩阵策略测试多个版本

### 监控和通知
- 设置状态检查
- 配置通知
- 监控工作流执行时间
- 跟踪失败率和趋势

### 测试策略
- 单元测试优先
- 集成测试补充
- E2E测试验证
- 性能测试检查