# src/ 源代码目录

此目录包含项目的核心源代码文件。

## 目录结构建议

```
src/
├── components/          # 可复用组件
│   ├── ui/             # UI基础组件
│   ├── forms/          # 表单组件
│   └── layout/         # 布局组件
├── pages/              # 页面组件
├── hooks/              # 自定义React Hooks
├── utils/              # 工具函数
├── services/           # API服务
├── stores/             # 状态管理
├── styles/             # 样式文件
├── assets/             # 资源文件
├── config/             # 配置文件
├── types/              # TypeScript类型定义
├── constants/          # 常量定义
└── index.ts            # 入口文件
```

## 文件命名规范

- 使用PascalCase命名组件和类
- 使用camelCase命名函数和变量
- 使用kebab-case命名文件和目录
- 使用UPPER_CASE命名常量

## 代码组织原则

1. **单一职责**: 每个文件应该只负责一个功能
2. **模块化**: 将相关功能组织在一起
3. **可复用性**: 提取公共逻辑为可复用组件
4. **可测试性**: 保持代码的可测试性
5. **可维护性**: 编写清晰、可读的代码

## 导入规范

```typescript
// 导入顺序
import React from 'react';
import { useState } from 'react';

// 第三方库
import axios from 'axios';

// 相对路径导入
import { utils } from '../utils';
import { Component } from './Component';

// 类型导入
import { User } from '../types';
```

## 注释规范

- 在复杂逻辑前添加注释
- 使用JSDoc注释函数和类
- 添加必要的代码说明
- 保持注释的更新和维护