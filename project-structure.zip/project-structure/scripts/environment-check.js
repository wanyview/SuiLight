#!/usr/bin/env node

/**
 * 环境检查和健康检查脚本
 * 检查系统环境、依赖和服务的健康状态
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');

class EnvironmentChecker {
  constructor() {
    this.checks = [];
    this.results = {
      passed: 0,
      failed: 0,
      warnings: 0,
      details: []
    };
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const colors = {
      info: '\x1b[36m',
      success: '\x1b[32m',
      warning: '\x1b[33m',
      error: '\x1b[31m',
      reset: '\x1b[0m'
    };
    
    console.log(`${colors[type]}[${timestamp}] ${message}${colors.reset}`);
  }

  async addCheck(name, checkFn, required = true) {
    this.checks.push({ name, checkFn, required });
  }

  async runCheck(check) {
    this.log(`执行检查: ${check.name}`);
    
    try {
      const result = await check.checkFn();
      const status = result ? 'passed' : 'failed';
      
      this.results.details.push({
        name: check.name,
        status,
        required: check.required,
        timestamp: new Date().toISOString()
      });
      
      if (status === 'passed') {
        this.results.passed++;
        this.log(`✓ ${check.name} - 通过`, 'success');
      } else {
        if (check.required) {
          this.results.failed++;
          this.log(`✗ ${check.name} - 失败`, 'error');
        } else {
          this.results.warnings++;
          this.log(`⚠ ${check.name} - 警告`, 'warning');
        }
      }
      
      return result;
    } catch (error) {
      this.results.details.push({
        name: check.name,
        status: 'error',
        required: check.required,
        error: error.message,
        timestamp: new Date().toISOString()
      });
      
      if (check.required) {
        this.results.failed++;
        this.log(`✗ ${check.name} - 错误: ${error.message}`, 'error');
      } else {
        this.results.warnings++;
        this.log(`⚠ ${check.name} - 警告: ${error.message}`, 'warning');
      }
      
      return false;
    }
  }

  async runAllChecks() {
    this.log('开始环境检查...');
    
    for (const check of this.checks) {
      await this.runCheck(check);
    }
    
    this.printSummary();
    return this.results.failed === 0;
  }

  printSummary() {
    console.log('\n' + '='.repeat(50));
    this.log('环境检查总结', 'info');
    console.log('='.repeat(50));
    this.log(`✓ 通过: ${this.results.passed}`, 'success');
    this.log(`✗ 失败: ${this.results.failed}`, 'error');
    this.log(`⚠ 警告: ${this.results.warnings}`, 'warning');
    console.log('='.repeat(50));
    
    if (this.results.failed > 0) {
      this.log('失败的检查:', 'error');
      this.results.details
        .filter(d => d.status === 'failed' || d.status === 'error')
        .forEach(d => this.log(`  - ${d.name}: ${d.error || '检查失败'}`, 'error'));
    }
  }

  // 检查系统要求
  checkSystemRequirements() {
    return {
      node: process.version,
      platform: process.platform,
      arch: process.arch,
      memory: Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + ' MB',
      uptime: Math.round(process.uptime()) + ' seconds'
    };
  }

  // 检查 Node.js 版本
  async checkNodeVersion() {
    const requiredVersion = '16.0.0';
    const currentVersion = process.version;
    const majorVersion = parseInt(currentVersion.slice(1).split('.')[0]);
    const requiredMajor = parseInt(requiredVersion.slice(1).split('.')[0]);
    
    return majorVersion >= requiredMajor;
  }

  // 检查包管理器
  async checkPackageManager() {
    try {
      execSync('pnpm --version', { stdio: 'ignore' });
      return true;
    } catch {
      try {
        execSync('npm --version', { stdio: 'ignore' });
        return true;
      } catch {
        return false;
      }
    }
  }

  // 检查必需的文件
  async checkRequiredFiles() {
    const requiredFiles = [
      'package.json',
      'vite.config.ts',
      'tsconfig.json'
    ];
    
    return requiredFiles.every(file => fs.existsSync(file));
  }

  // 检查依赖安装
  async checkDependencies() {
    try {
      if (fs.existsSync('node_modules')) {
        const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
        const deps = Object.keys(packageJson.dependencies || {});
        const devDeps = Object.keys(packageJson.devDependencies || {});
        
        const totalDeps = deps.length + devDeps.length;
        const installedDeps = fs.readdirSync('node_modules').length;
        
        return installedDeps >= Math.min(totalDeps, 10); // 至少安装部分依赖
      }
      return false;
    } catch {
      return false;
    }
  }

  // 检查端口可用性
  async checkPortAvailability(port = 3000) {
    return new Promise((resolve) => {
      const server = http.createServer();
      
      server.listen(port, () => {
        server.once('close', () => {
          resolve(true);
        });
        server.close();
      });
      
      server.on('error', () => {
        resolve(false);
      });
    });
  }

  // 检查网络连接
  async checkNetworkConnectivity() {
    return new Promise((resolve) => {
      const req = http.get('http://www.google.com', (res) => {
        resolve(res.statusCode === 200);
      });
      
      req.on('error', () => {
        resolve(false);
      });
      
      req.setTimeout(5000, () => {
        req.destroy();
        resolve(false);
      });
    });
  }

  // 检查磁盘空间
  async checkDiskSpace() {
    try {
      const stats = fs.statSync('.');
      // 简化的磁盘空间检查
      return true;
    } catch {
      return false;
    }
  }

  // 检查环境变量
  async checkEnvironmentVariables() {
    const requiredEnvVars = ['NODE_ENV'];
    const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);
    
    return missingVars.length === 0;
  }

  // 检查 Git 状态
  async checkGitStatus() {
    try {
      const status = execSync('git status --porcelain', { encoding: 'utf8' });
      return status.trim().length === 0;
    } catch {
      return true; // 如果不在 Git 仓库中，跳过此检查
    }
  }

  // 生成健康报告
  generateHealthReport() {
    const report = {
      timestamp: new Date().toISOString(),
      system: this.checkSystemRequirements(),
      checks: this.results,
      recommendations: this.generateRecommendations()
    };
    
    const reportPath = 'health-report.json';
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    this.log(`健康报告已生成: ${reportPath}`, 'success');
    
    return report;
  }

  generateRecommendations() {
    const recommendations = [];
    
    if (this.results.failed > 0) {
      recommendations.push('解决所有必需检查失败的问题');
    }
    
    if (this.results.warnings > 0) {
      recommendations.push('考虑解决警告项目以提高系统稳定性');
    }
    
    const failedChecks = this.results.details.filter(d => d.status === 'failed');
    if (failedChecks.some(c => c.name.includes('Node.js'))) {
      recommendations.push('升级 Node.js 到最新 LTS 版本');
    }
    
    if (failedChecks.some(c => c.name.includes('依赖'))) {
      recommendations.push('运行 npm install 或 pnpm install 安装依赖');
    }
    
    return recommendations;
  }

  async initialize() {
    // 添加所有检查
    await this.addCheck('Node.js 版本检查', () => this.checkNodeVersion(), true);
    await this.addCheck('包管理器检查', () => this.checkPackageManager(), true);
    await this.addCheck('必需文件检查', () => this.checkRequiredFiles(), true);
    await this.addCheck('依赖安装检查', () => this.checkDependencies(), true);
    await this.addCheck('端口可用性检查', () => this.checkPortAvailability(), false);
    await this.addCheck('网络连接检查', () => this.checkNetworkConnectivity(), false);
    await this.addCheck('磁盘空间检查', () => this.checkDiskSpace(), false);
    await this.addCheck('环境变量检查', () => this.checkEnvironmentVariables(), false);
    await this.addCheck('Git 状态检查', () => this.checkGitStatus(), false);
  }
}

// 命令行执行
async function main() {
  const checker = new EnvironmentChecker();
  await checker.initialize();
  
  const success = await checker.runAllChecks();
  checker.generateHealthReport();
  
  process.exit(success ? 0 : 1);
}

if (require.main === module) {
  main().catch(error => {
    console.error('环境检查失败:', error);
    process.exit(1);
  });
}

module.exports = EnvironmentChecker;