#!/usr/bin/env node

/**
 * 部署脚本 - 自动化部署流程
 * 支持多种部署目标和回滚机制
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');

class DeploymentManager {
  constructor() {
    this.config = this.loadConfig();
    this.deploymentId = this.generateDeploymentId();
    this.deploymentsDir = 'deployments';
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const colors = {
      info: '\x1b[36m',
      success: '\x1b[32m',
      warning: '\x1b[33m',
      error: '\x1b[31m',
      reset: '\x1b[0m'
    };
    
    console.log(`${colors[type]}[${timestamp}] ${message}${colors.reset}`);
  }

  loadConfig() {
    const configPath = './deployment.config.json';
    if (fs.existsSync(configPath)) {
      return JSON.parse(fs.readFileSync(configPath, 'utf8'));
    }
    
    // 默认配置
    return {
      environments: {
        development: {
          host: 'localhost',
          port: 3000,
          healthCheckUrl: 'http://localhost:3000/health',
          deployPath: './dist'
        },
        staging: {
          host: 'staging.example.com',
          port: 80,
          healthCheckUrl: 'http://staging.example.com/health',
          deployPath: '/var/www/staging'
        },
        production: {
          host: 'production.example.com',
          port: 80,
          healthCheckUrl: 'http://production.example.com/health',
          deployPath: '/var/www/production'
        }
      },
      healthCheckTimeout: 30000,
      healthCheckInterval: 5000,
      maxRetries: 3,
      rollbackRetention: 5
    };
  }

  generateDeploymentId() {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const random = Math.random().toString(36).substring(2, 8);
    return `deploy-${timestamp}-${random}`;
  }

  async validateEnvironment(environment) {
    this.log(`验证 ${environment} 环境...`);
    
    const envConfig = this.config.environments[environment];
    if (!envConfig) {
      throw new Error(`未知环境: ${environment}`);
    }

    // 检查构建文件是否存在
    if (!fs.existsSync(envConfig.deployPath)) {
      throw new Error(`构建目录不存在: ${envConfig.deployPath}`);
    }

    // 检查必要的文件
    const requiredFiles = ['index.html', 'assets'];
    const missingFiles = requiredFiles.filter(file => {
      const filePath = path.join(envConfig.deployPath, file);
      return !fs.existsSync(filePath);
    });

    if (missingFiles.length > 0) {
      throw new Error(`构建文件缺失: ${missingFiles.join(', ')}`);
    }

    this.log(`${environment} 环境验证通过`, 'success');
  }

  async deployToLocal(environment) {
    this.log(`部署到本地 ${environment} 环境...`);
    
    const envConfig = this.config.environments[environment];
    
    // 复制文件到部署目录
    const deployDir = path.join(this.deploymentsDir, this.deploymentId);
    if (!fs.existsSync(this.deploymentsDir)) {
      fs.mkdirSync(this.deploymentsDir, { recursive: true });
    }
    
    this.copyDirectory(envConfig.deployPath, deployDir);
    this.log(`文件已复制到: ${deployDir}`, 'success');
    
    return deployDir;
  }

  async deployToServer(environment) {
    this.log(`部署到服务器 ${environment} 环境...`);
    
    const envConfig = this.config.environments[environment];
    
    try {
      // 创建部署目录
      const backupDir = await this.createBackup(environment);
      
      // 部署新版本
      await this.copyFilesToServer(envConfig);
      
      // 记录部署信息
      await this.recordDeployment(environment, backupDir);
      
      this.log(`部署到 ${environment} 完成`, 'success');
      return true;
    } catch (error) {
      this.log(`部署失败: ${error.message}`, 'error');
      await this.rollback(environment);
      throw error;
    }
  }

  async createBackup(environment) {
    const envConfig = this.config.environments[environment];
    const backupDir = path.join(this.deploymentsDir, `backup-${Date.now()}`);
    
    if (fs.existsSync(envConfig.deployPath)) {
      this.copyDirectory(envConfig.deployPath, backupDir);
      this.log(`已创建备份: ${backupDir}`, 'success');
    }
    
    return backupDir;
  }

  copyDirectory(src, dest) {
    if (!fs.existsSync(src)) {
      throw new Error(`源目录不存在: ${src}`);
    }
    
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    
    const items = fs.readdirSync(src);
    items.forEach(item => {
      const srcPath = path.join(src, item);
      const destPath = path.join(dest, item);
      
      const stat = fs.statSync(srcPath);
      if (stat.isDirectory()) {
        this.copyDirectory(srcPath, destPath);
      } else {
        fs.copyFileSync(srcPath, destPath);
      }
    });
  }

  async copyFilesToServer(envConfig) {
    // 这里实现具体的服务器文件传输逻辑
    // 可以使用 scp, rsync, 或其他部署工具
    this.log('文件传输到服务器...', 'info');
    // 示例实现
    // execSync(`scp -r ${envConfig.deployPath}/* user@${envConfig.host}:${envConfig.deployPath}`);
  }

  async recordDeployment(environment, backupDir) {
    const deploymentRecord = {
      id: this.deploymentId,
      environment,
      timestamp: new Date().toISOString(),
      backupDir,
      status: 'deployed'
    };
    
    const recordPath = path.join(this.deploymentsDir, 'deployment-records.json');
    let records = [];
    
    if (fs.existsSync(recordPath)) {
      records = JSON.parse(fs.readFileSync(recordPath, 'utf8'));
    }
    
    records.push(deploymentRecord);
    
    // 只保留最近的记录
    if (records.length > this.config.rollbackRetention) {
      records = records.slice(-this.config.rollbackRetention);
    }
    
    fs.writeFileSync(recordPath, JSON.stringify(records, null, 2));
  }

  async healthCheck(environment) {
    this.log(`执行健康检查: ${environment}`);
    
    const envConfig = this.config.environments[environment];
    let attempts = 0;
    
    while (attempts < this.config.maxRetries) {
      try {
        const isHealthy = await this.pingHealthCheck(envConfig.healthCheckUrl);
        if (isHealthy) {
          this.log(`健康检查通过: ${environment}`, 'success');
          return true;
        }
      } catch (error) {
        this.log(`健康检查失败 (尝试 ${attempts + 1}/${this.config.maxRetries}): ${error.message}`, 'warning');
      }
      
      attempts++;
      if (attempts < this.config.maxRetries) {
        await this.sleep(this.config.healthCheckInterval);
      }
    }
    
    throw new Error(`健康检查失败，已达到最大重试次数: ${this.config.maxRetries}`);
  }

  async pingHealthCheck(url) {
    return new Promise((resolve, reject) => {
      const req = http.get(url, (res) => {
        resolve(res.statusCode === 200);
      });
      
      req.on('error', reject);
      req.setTimeout(10000, () => {
        req.destroy();
        reject(new Error('请求超时'));
      });
    });
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async rollback(environment) {
    this.log(`开始回滚 ${environment} 环境...`);
    
    const recordPath = path.join(this.deploymentsDir, 'deployment-records.json');
    
    if (!fs.existsSync(recordPath)) {
      throw new Error('没有找到部署记录');
    }
    
    const records = JSON.parse(fs.readFileSync(recordPath, 'utf8'));
    const successfulDeployments = records
      .filter(r => r.environment === environment && r.status === 'deployed')
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    if (successfulDeployments.length === 0) {
      throw new Error('没有找到可用的备份进行回滚');
    }
    
    const lastDeployment = successfulDeployments[1] || successfulDeployments[0]; // 第二个最新的是要回滚到的版本
    
    if (lastDeployment.backupDir && fs.existsSync(lastDeployment.backupDir)) {
      const envConfig = this.config.environments[environment];
      
      // 恢复备份
      this.copyDirectory(lastDeployment.backupDir, envConfig.deployPath);
      
      // 更新部署记录
      const latestRecord = records.find(r => r.id === this.deploymentId);
      if (latestRecord) {
        latestRecord.status = 'rolled-back';
        fs.writeFileSync(recordPath, JSON.stringify(records, null, 2));
      }
      
      this.log(`回滚完成，到版本: ${lastDeployment.id}`, 'success');
    } else {
      throw new Error('备份文件不存在，无法回滚');
    }
  }

  async deploy(environment) {
    try {
      this.log(`开始部署到 ${environment} 环境...`);
      
      await this.validateEnvironment(environment);
      
      if (environment === 'development') {
        await this.deployToLocal(environment);
      } else {
        await this.deployToServer(environment);
      }
      
      await this.healthCheck(environment);
      
      this.log(`🎉 部署到 ${environment} 成功！`, 'success');
      return true;
    } catch (error) {
      this.log(`部署失败: ${error.message}`, 'error');
      process.exit(1);
    }
  }
}

// 命令行参数解析
const args = process.argv.slice(2);
const environment = args.find(arg => arg.startsWith('--env='))?.split('=')[1] || 'development';

if (require.main === module) {
  const deployer = new DeploymentManager();
  deployer.deploy(environment);
}

module.exports = DeploymentManager;