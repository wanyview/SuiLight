# 构建和部署脚本目录

此目录包含项目的构建、部署、监控和维护相关的完整脚本系统。

## 🚀 脚本概览

```
scripts/
├── 📋 核心脚本
│   ├── deploy.js                    # 统一部署入口脚本
│   ├── build-scripts.js             # 智能构建脚本
│   ├── deploy-scripts.js            # 自动化部署脚本
│   ├── post-deploy-validate.js      # 部署后验证脚本
│   ├── rollback-manager.js          # 回滚管理脚本
│   └── environment-check.js         # 环境检查脚本
│
├── 🔧 Docker 配置文件
│   ├── Dockerfile                   # 多阶段构建镜像
│   ├── docker-compose.yml           # 应用服务编排
│   ├── docker-compose.monitoring.yml # 监控服务编排
│   ├── nginx.conf                   # Nginx 主配置
│   ├── default.conf                 # 站点配置
│   └── healthcheck.sh               # 容器健康检查
│
├── 📊 监控配置
│   ├── monitoring-setup.js          # 监控初始化脚本
│   ├── prometheus/                  # Prometheus 配置
│   ├── grafana/                     # Grafana 配置
│   ├── loki/                        # 日志收集配置
│   └── alertmanager/                # 告警配置
│
├── ⚙️ CI/CD 配置
│   ├── github-actions.yml           # GitHub Actions 工作流
│   └── deployment.config.json       # 部署配置文件
│
└── 📖 文档
    └── README.md                    # 本文档
```

## 🎯 快速开始

### 1. 完整部署流程
```bash
# 一键部署到开发环境
node scripts/deploy.js full-deploy --env=development

# 一键部署到生产环境
node scripts/deploy.js full-deploy --env=production
```

### 2. 分步骤执行
```bash
# 检查环境
node scripts/deploy.js check-env --env=development

# 构建应用
node scripts/deploy.js build --env=production

# 部署应用
node scripts/deploy.js deploy --env=production

# 验证部署
node scripts/deploy.js validate --env=production
```

## 📚 详细脚本说明

### 1. 统一部署脚本 (deploy.js)
**功能**: 提供统一的命令行界面，支持完整的部署生命周期管理。

**主要命令**:
- `full-deploy` - 完整部署流程
- `build` - 构建应用
- `deploy` - 部署应用
- `validate` - 验证部署
- `rollback` - 回滚应用
- `list-rollbacks` - 列出可回滚版本
- `cleanup` - 清理旧版本
- `init-monitoring` - 初始化监控
- `start-monitoring` - 启动监控

**使用示例**:
```bash
# 完整部署
node scripts/deploy.js full-deploy --env=staging --url=https://staging.example.com

# 回滚到上一个版本
node scripts/deploy.js rollback --env=production

# 回滚到指定版本
node scripts/deploy.js rollback --env=production --version=deploy-2024-01-01-12-00-00

# 列出可回滚版本
node scripts/deploy.js list-rollbacks --env=production

# 初始化监控
node scripts/deploy.js init-monitoring
```

### 2. 构建脚本 (build-scripts.js)
**功能**: 智能构建系统，支持多环境构建、依赖检查、测试运行。

**特性**:
- ✅ 环境检查 (Node.js版本、必需文件)
- ✅ 依赖安装和缓存
- ✅ 代码检查 (ESLint)
- ✅ 类型检查 (TypeScript)
- ✅ 测试执行
- ✅ 多环境构建 (dev/staging/production)
- ✅ 构建信息生成

**使用示例**:
```bash
# 开发环境构建
node scripts/build-scripts.js --env=development

# 生产环境构建
node scripts/build-scripts.js --env=production
```

### 3. 部署脚本 (deploy-scripts.js)
**功能**: 自动化部署系统，支持多环境部署、健康检查、备份管理。

**特性**:
- 🌍 多环境支持 (development/staging/production)
- 💾 自动备份创建
- 🔍 部署后健康检查
- 📝 部署记录跟踪
- 🔄 自动回滚机制

**配置示例**:
```json
{
  "environments": {
    "production": {
      "host": "production.example.com",
      "port": 80,
      "healthCheckUrl": "http://production.example.com/health",
      "deployPath": "/var/www/production"
    }
  }
}
```

### 4. 部署后验证 (post-deploy-validate.js)
**功能**: 全面验证部署结果，确保应用正常运行。

**验证项目**:
- 🌐 应用可访问性
- ❤️ 健康检查端点
- 📁 静态资源完整性
- 🔌 API 端点可用性
- ⏱️ 响应时间检查
- 📄 页面内容验证
- 🐛 错误处理检查
- 🌐 浏览器自动化测试

**使用示例**:
```bash
# 验证本地部署
node scripts/post-deploy-validate.js --env=development

# 验证远程部署
node scripts/post-deploy-validate.js --env=staging --url=https://staging.example.com
```

### 5. 回滚管理器 (rollback-manager.js)
**功能**: 智能回滚系统，支持多种回滚策略和自动回滚。

**特性**:
- 📋 部署历史跟踪
- 🔍 回滚候选版本验证
- 💾 自动备份管理
- ⚡ 自动回滚触发
- 📊 回滚统计记录

**使用示例**:
```bash
# 回滚到上一个版本
node scripts/rollback-manager.js rollback --env=production

# 回滚到指定版本
node scripts/rollback-manager.js rollback --env=staging --version=deploy-2024-01-01-12-00-00

# 列出可回滚版本
node scripts/rollback-manager.js list --env=production

# 清理旧版本
node scripts/rollback-manager.js cleanup --env=production
```

### 6. 环境检查 (environment-check.js)
**功能**: 全面的环境检查系统，确保部署环境符合要求。

**检查项目**:
- 🟢 Node.js 版本兼容性
- 📦 包管理器可用性
- 📁 必需文件检查
- 📚 依赖安装状态
- 🔌 端口可用性
- 🌐 网络连接检查
- 💾 磁盘空间检查
- 🔧 环境变量检查
- 📊 Git 状态检查

**使用示例**:
```bash
# 环境检查
node scripts/environment-check.js
```

## 🐳 Docker 配置

### Dockerfile
多阶段构建，优化镜像大小和安全性：
- 构建阶段: Node.js 18 Alpine
- 运行阶段: Nginx Alpine
- 健康检查: 自定义脚本
- 安全配置: 非 root 用户

### Docker Compose
完整的服务编排，包括：
- 🌐 前端应用 (Nginx)
- 🔧 后端 API (Node.js)
- 💾 Redis 缓存
- 🗄️ PostgreSQL 数据库
- 📊 监控服务 (Prometheus, Grafana, Loki)

**启动服务**:
```bash
# 启动所有服务
docker-compose -f scripts/docker-compose.yml up -d

# 启动监控服务
docker-compose -f scripts/docker-compose.monitoring.yml up -d
```

## 📊监控 配置

### 监控组件
- **Prometheus**: 指标收集和存储
- **Grafana**: 可视化仪表板
- **Loki**: 日志聚合
- **Alertmanager**: 告警管理

### 监控指标
- 📈 HTTP 请求率
- ⏱️ 响应时间分布
- 📉 错误率
- 💾 内存使用率
- 🖥️ CPU 使用率
- 💿 磁盘空间
- 🔌 服务可用性

### 告警规则
- ⚠️ 高错误率告警
- ⏱️ 响应时间告警
- 💾 内存使用告警
- 🖥️ CPU 使用告警
- 💿 磁盘空间告警
- 🔌 服务下线告警

**初始化监控**:
```bash
# 初始化监控配置
node scripts/monitoring-setup.js init

# 启动监控服务
node scripts/monitoring-setup.js start

# 或使用统一脚本
node scripts/deploy.js init-monitoring
node scripts/deploy.js start-monitoring
```

**访问监控界面**:
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3001 (admin/admin)
- Alertmanager: http://localhost:9093

## 🔄 CI/CD 配置

### GitHub Actions 工作流
自动化 CI/CD 流程，包括：
- ✅ 代码质量检查
- 🔒 安全扫描
- 🧪 测试执行
- 🔨 多环境构建
- 🚀 自动部署
- ✅ 部署后验证

**工作流触发**:
- `push` 到 `main` 或 `develop` 分支
- `pull_request` 到 `main` 分支
- 定时任务 (每日凌晨2点)

## ⚙️ 配置说明

### 部署配置 (deployment.config.json)
```json
{
  "environments": {
    "development": {
      "host": "localhost",
      "port": 3000,
      "healthCheckUrl": "http://localhost:3000/health",
      "deployPath": "./dist"
    },
    "production": {
      "host": "production.example.com",
      "port": 80,
      "healthCheckUrl": "http://production.example.com/health",
      "deployPath": "/var/www/production"
    }
  },
  "healthCheckTimeout": 30000,
  "healthCheckInterval": 5000,
  "maxRetries": 3,
  "rollbackRetention": 5
}
```

### 回滚配置 (rollback.config.json)
```json
{
  "strategies": {
    "automatic": {
      "enabled": true,
      "triggers": [
        "health_check_failed",
        "response_time_slow",
        "error_rate_high",
        "deployment_validation_failed"
      ],
      "maxRollbackAttempts": 3
    },
    "manual": {
      "confirmationRequired": true,
      "confirmationTimeout": 30000
    }
  },
  "environments": {
    "production": {
      "autoRollback": false,
      "backupRetention": 10
    }
  }
}
```

## 🛡️ 安全考虑

### 构建安全
- ✅ 多阶段构建减少攻击面
- ✅ 非 root 用户运行
- ✅ 依赖漏洞扫描
- ✅ 镜像签名验证

### 部署安全
- 🔐 环境变量管理
- 🔒 网络安全配置
- 🛡️ 安全头设置
- 🔍 访问控制

### 监控安全
- 🔐 Grafana 认证
- 📊 指标访问控制
- 🚨 告警权限管理

## 📈 最佳实践

### 1. 环境管理
- 🏷️ 使用环境变量区分配置
- 📁 为每个环境维护独立的配置文件
- 🔄 使用蓝绿部署减少停机时间

### 2. 错误处理
- 🛡️ 所有脚本包含完善的错误处理
- 📝 提供详细的错误日志
- 🔄 自动重试机制

### 3. 监控和告警
- 📊 设置全面的监控指标
- 🚨 配置适当的告警阈值
- 📱 集成多种通知方式

### 4. 回滚策略
- 💾 保持足够的备份版本
- ⚡ 实现快速回滚机制
- 🧪 定期测试回滚流程

### 5. 文档维护
- 📖 及时更新文档
- 🔄 保持配置同步
- 📋 记录变更历史

## 🔧 故障排除

### 常见问题

**构建失败**:
```bash
# 检查环境
node scripts/environment-check.js

# 清理并重新构建
rm -rf node_modules dist
npm install
node scripts/build-scripts.js --env=development
```

**部署失败**:
```bash
# 检查健康状态
curl -f http://your-domain.com/health

# 查看部署日志
tail -f deployments/deployment-records.json

# 执行回滚
node scripts/deploy.js rollback --env=production
```

**监控服务问题**:
```bash
# 重启监控服务
docker-compose -f scripts/docker-compose.monitoring.yml restart

# 检查服务状态
docker-compose -f scripts/docker-compose.monitoring.yml ps

# 查看服务日志
docker-compose -f scripts/docker-compose.monitoring.yml logs
```

## 📞 技术支持

如遇到问题，请检查：
1. 📋 查看脚本执行日志
2. 🔍 运行环境检查脚本
3. 📊 查看监控面板
4. 🔄 尝试回滚到稳定版本
5. 📝 查阅部署记录

## 📝 更新日志

- **v1.0.0** (2025-12-06): 初始版本，包含完整的构建部署系统
  - ✅ 智能构建脚本
  - ✅ 自动化部署
  - ✅ 回滚管理
  - ✅ 监控配置
  - ✅ CI/CD 工作流

---

🎉 **祝您部署愉快！如有问题，请参考上述文档或联系开发团队。**