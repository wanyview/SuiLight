#!/bin/sh

# Docker 健康检查脚本

set -e

# 配置
HEALTH_CHECK_URL="${HEALTH_CHECK_URL:-http://localhost:80/health}"
MAX_RETRIES="${MAX_RETRIES:-3}"
RETRY_INTERVAL="${RETRY_INTERVAL:-5}"
TIMEOUT="${TIMEOUT:-10}"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

log_success() {
    log "${GREEN}✓ $1${NC}"
}

log_warning() {
    log "${YELLOW}⚠ $1${NC}"
}

log_error() {
    log "${RED}✗ $1${NC}"
}

check_http_response() {
    local url=$1
    local expected_status=${2:-200}
    
    # 使用 curl 进行 HTTP 检查
    if command -v curl >/dev/null 2>&1; then
        local response_code
        response_code=$(curl -s -o /dev/null -w "%{http_code}" \
            --max-time "$TIMEOUT" \
            --retry 0 \
            "$url" 2>/dev/null || echo "000")
        
        if [ "$response_code" = "$expected_status" ]; then
            return 0
        else
            log_warning "HTTP 状态码: $response_code (期望: $expected_status)"
            return 1
        fi
    else
        log_warning "curl 命令不可用，尝试使用 wget"
        
        if command -v wget >/dev/null 2>&1; then
            if wget -q -T "$TIMEOUT" --spider "$url" 2>/dev/null; then
                return 0
            else
                log_error "wget 检查失败"
                return 1
            fi
        else
            log_error "curl 和 wget 都不可用"
            return 1
        fi
    fi
}

check_process() {
    local process_name=$1
    
    if pgrep -f "$process_name" >/dev/null 2>&1; then
        return 0
    else
        log_error "进程 $process_name 未运行"
        return 1
    fi
}

check_disk_space() {
    local threshold=${1:-90}
    local usage
    
    usage=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
    
    if [ "$usage" -lt "$threshold" ]; then
        return 0
    else
        log_error "磁盘使用率过高: ${usage}% (阈值: ${threshold}%)"
        return 1
    fi
}

check_memory() {
    local threshold=${1:-90}
    local usage
    
    # 获取内存使用率
    if [ -f /proc/meminfo ]; then
        local total available
        total=$(grep MemTotal /proc/meminfo | awk '{print $2}')
        available=$(grep MemAvailable /proc/meminfo | awk '{print $2}')
        
        if [ "$total" -gt 0 ]; then
            usage=$((100 - (available * 100 / total)))
            
            if [ "$usage" -lt "$threshold" ]; then
                return 0
            else
                log_error "内存使用率过高: ${usage}% (阈值: ${threshold}%)"
                return 1
            fi
        fi
    fi
    
    log_warning "无法检查内存使用率"
    return 1
}

main() {
    local checks_passed=0
    local total_checks=0
    
    log "开始健康检查..."
    
    # 检查 HTTP 响应
    total_checks=$((total_checks + 1))
    if check_http_response "$HEALTH_CHECK_URL"; then
        checks_passed=$((checks_passed + 1))
        log_success "HTTP 健康检查通过"
    else
        log_error "HTTP 健康检查失败"
    fi
    
    # 检查 Nginx 进程
    total_checks=$((total_checks + 1))
    if check_process "nginx"; then
        checks_passed=$((checks_passed + 1))
        log_success "Nginx 进程检查通过"
    else
        log_error "Nginx 进程检查失败"
    fi
    
    # 检查磁盘空间
    total_checks=$((total_checks + 1))
    if check_disk_space 90; then
        checks_passed=$((checks_passed + 1))
        log_success "磁盘空间检查通过"
    else
        log_error "磁盘空间检查失败"
    fi
    
    # 检查内存使用率
    total_checks=$((total_checks + 1))
    if check_memory 90; then
        checks_passed=$((checks_passed + 1))
        log_success "内存检查通过"
    else
        log_error "内存检查失败"
    fi
    
    # 输出检查结果
    log "健康检查完成: $checks_passed/$total_checks 项检查通过"
    
    if [ "$checks_passed" -eq "$total_checks" ]; then
        log_success "所有健康检查通过"
        exit 0
    else
        log_error "健康检查失败: $checks_passed/$total_checks 项检查通过"
        exit 1
    fi
}

# 如果直接执行此脚本
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    main "$@"
fi