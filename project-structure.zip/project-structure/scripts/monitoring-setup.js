#!/usr/bin/env node

/**
 * 监控和日志配置脚本
 * 配置应用程序监控、日志收集和告警系统
 */

const fs = require('fs');
const path = require('path');

class MonitoringManager {
  constructor() {
    this.monitoringDir = 'monitoring';
    this.config = {
      prometheus: {
        enabled: true,
        port: 9090,
        retention: '200h',
        scrape_interval: '15s'
      },
      grafana: {
        enabled: true,
        port: 3001,
        admin_user: 'admin',
        admin_password: 'admin'
      },
      log aggregation: {
        enabled: true,
        elasticsearch: {
          enabled: false,
          host: 'localhost',
          port: 9200
        },
        loki: {
          enabled: true,
          host: 'localhost',
          port: 3100
        }
      },
      alerting: {
        enabled: true,
        slack: {
          enabled: false,
          webhook_url: '',
          channel: '#alerts'
        },
        email: {
          enabled: false,
          smtp_server: '',
          smtp_port: 587,
          username: '',
          password: '',
          to: []
        }
      }
    };
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const colors = {
      info: '\x1b[36m',
      success: '\x1b[32m',
      warning: '\x1b[33m',
      error: '\x1b[31m',
      reset: '\x1b[0m'
    };
    
    console.log(`${colors[type]}[${timestamp}] ${message}${colors.reset}`);
  }

  // 创建监控目录结构
  createMonitoringDirectories() {
    const dirs = [
      this.monitoringDir,
      `${this.monitoringDir}/grafana`,
      `${this.monitoringDir}/grafana/dashboards`,
      `${this.monitoringDir}/grafana/provisioning`,
      `${this.monitoringDir}/grafana/provisioning/datasources`,
      `${this.monitoringDir}/grafana/provisioning/dashboards`,
      `${this.monitoringDir}/prometheus`,
      `${this.monitoringDir}/loki`,
      `${this.monitoringDir}/alertmanager`
    ];
    
    dirs.forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        this.log(`创建目录: ${dir}`, 'success');
      }
    });
  }

  // 生成 Prometheus 配置
  generatePrometheusConfig() {
    const config = `global:
  scrape_interval: ${this.config.prometheus.scrape_interval}
  evaluation_interval: 15s

rule_files:
  - "alert_rules.yml"

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']

  - job_name: 'frontend'
    static_configs:
      - targets: ['frontend:80']
    metrics_path: '/metrics'
    scrape_interval: 30s

  - job_name: 'nginx-exporter'
    static_configs:
      - targets: ['nginx-exporter:9113']

  - job_name: 'application'
    static_configs:
      - targets: ['app:3000']
    metrics_path: '/api/metrics'
    scrape_interval: 30s`;

    const configPath = path.join(this.monitoringDir, 'prometheus', 'prometheus.yml');
    fs.writeFileSync(configPath, config);
    this.log('Prometheus 配置已生成', 'success');
  }

  // 生成 Prometheus 告警规则
  generateAlertRules() {
    const rules = `groups:
  - name: application
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.1
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High error rate detected"
          description: "Error rate is {{ $value }} errors per second"

      - alert: HighResponseTime
        expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 2
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "High response time detected"
          description: "95th percentile response time is {{ $value }}s"

      - alert: HighMemoryUsage
        expr: (1 - (node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes)) * 100 > 80
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High memory usage detected"
          description: "Memory usage is {{ $value }}%"

      - alert: HighCpuUsage
        expr: 100 - (avg by(instance) (irate(node_cpu_seconds_total{mode="idle"}[5m])) * 100) > 80
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "High CPU usage detected"
          description: "CPU usage is {{ $value }}%"

      - alert: DiskSpaceLow
        expr: (node_filesystem_avail_bytes{mountpoint="/"} / node_filesystem_size_bytes{mountpoint="/"}) * 100 < 10
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Disk space is critically low"
          description: "Disk space is {{ $value }}% full"

      - alert: ServiceDown
        expr: up == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Service is down"
          description: "{{ $labels.job }} service is down"`;

    const rulesPath = path.join(this.monitoringDir, 'prometheus', 'alert_rules.yml');
    fs.writeFileSync(rulesPath, rules);
    this.log('Prometheus 告警规则已生成', 'success');
  }

  // 生成 Grafana 数据源配置
  generateGrafanaDatasources() {
    const datasourceConfig = `apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
    editable: true

  - name: Loki
    type: loki
    access: proxy
    url: http://loki:3100
    editable: true`;

    const configPath = path.join(
      this.monitoringDir, 
      'grafana', 
      'provisioning', 
      'datasources', 
      'datasources.yml'
    );
    fs.writeFileSync(configPath, datasourceConfig);
    this.log('Grafana 数据源配置已生成', 'success');
  }

  // 生成 Grafana 仪表板配置
  generateGrafanaDashboards() {
    const dashboardConfig = `apiVersion: 1

providers:
  - name: 'default'
    orgId: 1
    folder: ''
    type: file
    disableDeletion: false
    updateIntervalSeconds: 10
    allowUiUpdates: true
    options:
      path: /etc/grafana/provisioning/dashboards`;

    const configPath = path.join(
      this.monitoringDir, 
      'grafana', 
      'provisioning', 
      'dashboards', 
      'dashboards.yml'
    );
    fs.writeFileSync(configPath, dashboardConfig);
    this.log('Grafana 仪表板配置已生成', 'success');
  }

  // 生成应用仪表板
  generateApplicationDashboard() {
    const dashboard = {
      dashboard: {
        id: null,
        title: "Application Monitoring",
        tags: ["application"],
        style: "dark",
        timezone: "browser",
        panels: [
          {
            id: 1,
            title: "Request Rate",
            type: "graph",
            targets: [
              {
                expr: "rate(http_requests_total[5m])",
                legendFormat: "{{method}} {{status}}"
              }
            ],
            gridPos: { h: 8, w: 12, x: 0, y: 0 }
          },
          {
            id: 2,
            title: "Response Time",
            type: "graph",
            targets: [
              {
                expr: "histogram_quantile(0.50, rate(http_request_duration_seconds_bucket[5m]))",
                legendFormat: "50th percentile"
              },
              {
                expr: "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))",
                legendFormat: "95th percentile"
              },
              {
                expr: "histogram_quantile(0.99, rate(http_request_duration_seconds_bucket[5m]))",
                legendFormat: "99th percentile"
              }
            ],
            gridPos: { h: 8, w: 12, x: 12, y: 0 }
          },
          {
            id: 3,
            title: "Error Rate",
            type: "graph",
            targets: [
              {
                expr: "rate(http_requests_total{status=~\"5..\"}[5m])",
                legendFormat: "5xx errors"
              }
            ],
            gridPos: { h: 8, w: 12, x: 0, y: 8 }
          },
          {
            id: 4,
            title: "Active Users",
            type: "stat",
            targets: [
              {
                expr: "http_requests_total",
                legendFormat: "Total Requests"
              }
            ],
            gridPos: { h: 8, w: 12, x: 12, y: 8 }
          }
        ],
        time: { from: "now-1h", to: "now" },
        refresh: "30s"
      }
    };

    const dashboardPath = path.join(
      this.monitoringDir, 
      'grafana', 
      'dashboards', 
      'application-monitoring.json'
    );
    fs.writeFileSync(dashboardPath, JSON.stringify(dashboard, null, 2));
    this.log('应用仪表板已生成', 'success');
  }

  // 生成 Loki 配置
  generateLokiConfig() {
    const config = `auth_enabled: false

server:
  http_listen_port: 3100
  grpc_listen_port: 9096

common:
  path_prefix: /tmp/loki
  storage:
    filesystem:
      chunks_directory: /tmp/loki/chunks
      rules_directory: /tmp/loki/rules
  replication_factor: 1
  ring:
    instance_addr: 127.0.0.1
    kvstore:
      store: inmemory

query_range:
  results_cache:
    cache:
      embedded_cache:
        enabled: true
        max_size_mb: 100

schema_config:
  configs:
    - from: 2020-10-24
      store: boltdb-shipper
      object_store: filesystem
      schema: v11
      index:
        prefix: index_
        period: 24h

ruler:
  alertmanager_url: http://alertmanager:9093

limits_config:
  enforce_metric_name: false
  reject_old_samples: true
  reject_old_samples_max_age: 168h
  creation_grace_period: 10m

frontend_log_logql:
  enabled: true`;

    const configPath = path.join(this.monitoringDir, 'loki', 'loki.yml');
    fs.writeFileSync(configPath, config);
    this.log('Loki 配置已生成', 'success');
  }

  // 生成 Alertmanager 配置
  generateAlertmanagerConfig() {
    const config = `global:
  smtp_smarthost: 'localhost:587'
  smtp_from: 'alertmanager@example.com'

route:
  group_by: ['alertname']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 1h
  receiver: 'web.hook'
  routes:
    - match:
        severity: critical
      receiver: 'critical-alerts'

receivers:
  - name: 'web.hook'
    webhook_configs:
      - url: 'http://127.0.0.1:5001/'

  - name: 'critical-alerts'
    email_configs:
      - to: 'admin@example.com'
        subject: 'CRITICAL: {{ range .Alerts }}{{ .Annotations.summary }}{{ end }}'
        body: |
          {{ range .Alerts }}
          Alert: {{ .Annotations.summary }}
          Description: {{ .Annotations.description }}
          {{ end }}
    slack_configs:
      - api_url: '${SLACK_WEBHOOK_URL}'
        channel: '#alerts'
        title: 'CRITICAL Alert'
        text: '{{ range .Alerts }}{{ .Annotations.summary }}{{ end }}'`;

    const configPath = path.join(this.monitoringDir, 'alertmanager', 'alertmanager.yml');
    fs.writeFileSync(configPath, config);
    this.log('Alertmanager 配置已生成', 'success');
  }

  // 生成日志收集配置
  generateLogConfig() {
    const fluentdConfig = `<source>
  @type tail
  @id nginx_access
  path /var/log/nginx/access.log
  pos_file /var/log/fluentd-nginx-access.log.pos
  tag nginx.access
  
  <parse>
    @type nginx
  </parse>
</source>

<source>
  @type tail
  @id nginx_error
  path /var/log/nginx/error.log
  pos_file /var/log/fluentd-nginx-error.log.pos
  tag nginx.error
  
  <parse>
    @type regexp
    expression /^(?<time>[^ ]* [^ ]*) \[(?<log_level>[^\]]*)\] (?<message>.*)$/
    time_format %d/%b/%Y:%H:%M:%S %z
  </parse>
</source>

<match nginx.**>
  @type loki
  url "#{ENV['LOKI_URL']}"
  tenant_key application
  <label>
    @name nginx
  </label>
  <buffer>
    @type memory
    flush_interval 10s
  </buffer>
</match>`;

    const configPath = path.join(this.monitoringDir, 'fluentd.conf');
    fs.writeFileSync(configPath, fluentdConfig);
    this.log('日志收集配置已生成', 'success');
  }

  // 生成应用监控中间件
  generateAppMonitoring() {
    const monitoringMiddleware = `// 监控中间件
const promClient = require('prom-client');

// 创建指标
const httpRequestDuration = new promClient.Histogram({
  name: 'http_request_duration_seconds',
  help: 'HTTP request duration in seconds',
  labelNames: ['method', 'route', 'status_code'],
  buckets: [0.1, 0.3, 0.5, 0.7, 1, 3, 5, 7, 10]
});

const httpRequestTotal = new promClient.Counter({
  name: 'http_requests_total',
  help: 'Total number of HTTP requests',
  labelNames: ['method', 'route', 'status_code']
});

const activeConnections = new promClient.Gauge({
  name: 'active_connections',
  help: 'Number of active connections'
});

// 监控中间件
function monitoringMiddleware(req, res, next) {
  const start = Date.now();
  
  res.on('finish', () => {
    const duration = (Date.now() - start) / 1000;
    const route = req.route ? req.route.path : req.path;
    
    httpRequestDuration
      .labels(req.method, route, res.statusCode)
      .observe(duration);
      
    httpRequestTotal
      .labels(req.method, route, res.statusCode)
      .inc();
  });
  
  next();
}

// 健康检查端点
function healthCheckHandler(req, res) {
  const health = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    version: process.env.npm_package_version || '1.0.0'
  };
  
  res.json(health);
}

// 指标端点
function metricsHandler(req, res) {
  res.set('Content-Type', promClient.register.contentType);
  res.end(promClient.register.metrics());
}

module.exports = {
  monitoringMiddleware,
  healthCheckHandler,
  metricsHandler
};`;

    const middlewarePath = path.join('src', 'monitoring.js');
    fs.writeFileSync(middlewarePath, monitoringMiddleware);
    this.log('应用监控中间件已生成', 'success');
  }

  // 生成监控启动脚本
  generateMonitoringScript() {
    const script = `#!/bin/bash

# 监控服务启动脚本

set -e

MONITORING_DIR="./monitoring"
COMPOSE_FILE="./scripts/docker-compose.monitoring.yml"

echo "🚀 启动监控服务..."

# 检查 Docker 和 Docker Compose
if ! command -v docker &> /dev/null; then
    echo "❌ Docker 未安装"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose 未安装"
    exit 1
fi

# 启动监控服务
echo "📊 启动 Prometheus..."
docker-compose -f $COMPOSE_FILE up -d prometheus

echo "📈 启动 Grafana..."
docker-compose -f $COMPOSE_FILE up -d grafana

echo "📋 启动 Loki..."
docker-compose -f $COMPOSE_FILE up -d loki

echo "🚨 启动 Alertmanager..."
docker-compose -f $COMPOSE_FILE up -d alertmanager

echo "⏱️  等待服务启动..."
sleep 30

# 检查服务状态
echo "🔍 检查服务状态..."
docker-compose -f $COMPOSE_FILE ps

echo ""
echo "✅ 监控服务启动完成！"
echo ""
echo "🌐 访问地址:"
echo "   Prometheus: http://localhost:9090"
echo "   Grafana:    http://localhost:3001 (admin/admin)"
echo "   Alertmanager: http://localhost:9093"
echo ""
echo "📊 默认仪表板:"
echo "   应用监控: http://localhost:3001/d/application-monitoring"`;

    const scriptPath = path.join(this.monitoringDir, 'start-monitoring.sh');
    fs.writeFileSync(scriptPath, script);
    
    // 添加执行权限
    try {
      execSync(`chmod +x ${scriptPath}`);
    } catch (error) {
      // Windows 系统上可能不支持 chmod
    }
    
    this.log('监控启动脚本已生成', 'success');
  }

  // 生成 Docker Compose 监控配置
  generateMonitoringCompose() {
    const composeConfig = `version: '3.8'

services:
  prometheus:
    image: prom/prometheus:latest
    container_name: prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus:/etc/prometheus
      - prometheus-data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--storage.tsdb.retention.time=200h'
      - '--web.enable-lifecycle'
    restart: unless-stopped
    networks:
      - monitoring

  grafana:
    image: grafana/grafana:latest
    container_name: grafana
    ports:
      - "3001:3000"
    environment:
      - GF_SECURITY_ADMIN_USER=admin
      - GF_SECURITY_ADMIN_PASSWORD=admin
    volumes:
      - grafana-data:/var/lib/grafana
      - ./monitoring/grafana:/etc/grafana/provisioning
    restart: unless-stopped
    networks:
      - monitoring
    depends_on:
      - prometheus

  loki:
    image: grafana/loki:latest
    container_name: loki
    ports:
      - "3100:3100"
    volumes:
      - ./monitoring/loki/loki.yml:/etc/loki/local-config.yaml
      - loki-data:/loki
    command: -config.file=/etc/loki/local-config.yaml
    restart: unless-stopped
    networks:
      - monitoring

  alertmanager:
    image: prom/alertmanager:latest
    container_name: alertmanager
    ports:
      - "9093:9093"
    volumes:
      - ./monitoring/alertmanager/alertmanager.yml:/etc/alertmanager/alertmanager.yml
    restart: unless-stopped
    networks:
      - monitoring

volumes:
  prometheus-data:
    driver: local
  grafana-data:
    driver: local
  loki-data:
    driver: local

networks:
  monitoring:
    driver: bridge`;

    const composePath = path.join('scripts', 'docker-compose.monitoring.yml');
    fs.writeFileSync(composePath, composeConfig);
    this.log('监控 Docker Compose 配置已生成', 'success');
  }

  // 初始化完整监控配置
  async initializeMonitoring() {
    this.log('开始初始化监控配置...');
    
    try {
      this.createMonitoringDirectories();
      this.generatePrometheusConfig();
      this.generateAlertRules();
      this.generateGrafanaDatasources();
      this.generateGrafanaDashboards();
      this.generateApplicationDashboard();
      this.generateLokiConfig();
      this.generateAlertmanagerConfig();
      this.generateLogConfig();
      this.generateAppMonitoring();
      this.generateMonitoringScript();
      this.generateMonitoringCompose();
      
      this.log('✅ 监控配置初始化完成！', 'success');
      
      console.log('\n📊 监控服务使用指南:');
      console.log('='.repeat(50));
      console.log('1. 启动监控服务:');
      console.log('   cd monitoring && ./start-monitoring.sh');
      console.log('');
      console.log('2. 访问监控界面:');
      console.log('   Prometheus: http://localhost:9090');
      console.log('   Grafana:    http://localhost:3001 (admin/admin)');
      console.log('   Alertmanager: http://localhost:9093');
      console.log('');
      console.log('3. 在应用中使用监控中间件:');
      console.log('   const { monitoringMiddleware } = require("./monitoring");');
      console.log('   app.use(monitoringMiddleware);');
      console.log('');
      console.log('4. 配置告警:');
      console.log('   - 编辑 monitoring/alertmanager/alertmanager.yml');
      console.log('   - 设置 Slack 或邮件告警');
      console.log('='.repeat(50));
      
    } catch (error) {
      this.log(`监控配置初始化失败: ${error.message}`, 'error');
      throw error;
    }
  }
}

// 命令行执行
async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'init';
  
  const monitoringManager = new MonitoringManager();
  
  switch (command) {
    case 'init':
      await monitoringManager.initializeMonitoring();
      break;
      
    case 'start':
      console.log('启动监控服务...');
      execSync('cd monitoring && ./start-monitoring.sh', { stdio: 'inherit' });
      break;
      
    default:
      console.log(`
用法:
  node monitoring-setup.js init    # 初始化监控配置
  node monitoring-setup.js start   # 启动监控服务

示例:
  node monitoring-setup.js init
  node monitoring-setup.js start
      `);
      process.exit(1);
  }
}

if (require.main === module) {
  main().catch(error => {
    console.error('监控配置失败:', error);
    process.exit(1);
  });
}

module.exports = MonitoringManager;