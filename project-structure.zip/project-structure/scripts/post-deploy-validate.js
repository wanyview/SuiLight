#!/usr/bin/env node

/**
 * 部署后验证脚本
 * 验证部署是否成功，包括功能测试、健康检查等
 */

const { execSync } = require('child_process');
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

class PostDeployValidator {
  constructor() {
    this.environment = process.env.DEPLOY_ENV || 'development';
    this.baseUrl = process.env.BASE_URL || 'http://localhost:3000';
    this.validationResults = {
      passed: 0,
      failed: 0,
      warnings: 0,
      tests: []
    };
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const colors = {
      info: '\x1b[36m',
      success: '\x1b[32m',
      warning: '\x1b[33m',
      error: '\x1b[31m',
      reset: '\x1b[0m'
    };
    
    console.log(`${colors[type]}[${timestamp}] ${message}${colors.reset}`);
  }

  async addTest(name, testFn, required = true) {
    this.validationResults.tests.push({ name, testFn, required });
  }

  async runTest(test) {
    this.log(`执行测试: ${test.name}`);
    
    try {
      const result = await test.testFn();
      const status = result ? 'passed' : 'failed';
      
      if (status === 'passed') {
        this.validationResults.passed++;
        this.log(`✓ ${test.name} - 通过`, 'success');
      } else {
        if (test.required) {
          this.validationResults.failed++;
          this.log(`✗ ${test.name} - 失败`, 'error');
        } else {
          this.validationResults.warnings++;
          this.log(`⚠ ${test.name} - 警告`, 'warning');
        }
      }
      
      return result;
    } catch (error) {
      this.validationResults.failed++;
      this.log(`✗ ${test.name} - 错误: ${error.message}`, 'error');
      return false;
    }
  }

  async runAllTests() {
    this.log(`开始部署后验证 (环境: ${this.environment})...`);
    
    for (const test of this.validationResults.tests) {
      await this.runTest(test);
    }
    
    this.printSummary();
    return this.validationResults.failed === 0;
  }

  printSummary() {
    console.log('\n' + '='.repeat(60));
    this.log('部署后验证总结', 'info');
    console.log('='.repeat(60));
    this.log(`✓ 通过: ${this.validationResults.passed}`, 'success');
    this.log(`✗ 失败: ${this.validationResults.failed}`, 'error');
    this.log(`⚠ 警告: ${this.validationResults.warnings}`, 'warning');
    console.log('='.repeat(60));
    
    if (this.validationResults.failed > 0) {
      this.log('失败的测试:', 'error');
      this.validationResults.tests
        .filter((_, index) => this.validationResults.tests[index].status === 'failed')
        .forEach(test => this.log(`  - ${test.name}`, 'error'));
    }
  }

  // HTTP 请求工具方法
  makeRequest(url, options = {}) {
    return new Promise((resolve, reject) => {
      const urlObj = new URL(url);
      const client = urlObj.protocol === 'https:' ? https : http;
      
      const requestOptions = {
        hostname: urlObj.hostname,
        port: urlObj.port,
        path: urlObj.pathname + urlObj.search,
        method: options.method || 'GET',
        headers: {
          'User-Agent': 'PostDeployValidator/1.0',
          ...options.headers
        },
        timeout: options.timeout || 10000
      };
      
      const req = client.request(requestOptions, (res) => {
        let data = '';
        
        res.on('data', (chunk) => {
          data += chunk;
        });
        
        res.on('end', () => {
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            body: data,
            success: res.statusCode >= 200 && res.statusCode < 300
          });
        });
      });
      
      req.on('error', reject);
      req.on('timeout', () => {
        req.destroy();
        reject(new Error('请求超时'));
      });
      
      if (options.data) {
        req.write(options.data);
      }
      
      req.end();
    });
  }

  // 检查应用可访问性
  async checkApplicationAccessibility() {
    try {
      const response = await this.makeRequest(this.baseUrl);
      return response.success && response.statusCode === 200;
    } catch (error) {
      this.log(`应用访问失败: ${error.message}`, 'error');
      return false;
    }
  }

  // 检查健康检查端点
  async checkHealthEndpoint() {
    try {
      const healthUrl = `${this.baseUrl}/health`;
      const response = await this.makeRequest(healthUrl);
      
      if (response.success) {
        try {
          const healthData = JSON.parse(response.body);
          this.log(`健康检查数据: ${JSON.stringify(healthData)}`, 'info');
          return true;
        } catch {
          // 如果不是 JSON 格式，只要状态码正确就认为通过
          return true;
        }
      }
      return false;
    } catch (error) {
      this.log(`健康检查端点失败: ${error.message}`, 'error');
      return false;
    }
  }

  // 检查静态资源
  async checkStaticAssets() {
    try {
      // 检查主要的静态资源文件
      const assetsToCheck = [
        '/assets/index.css',
        '/assets/index.js',
        '/favicon.ico'
      ];
      
      let passedChecks = 0;
      
      for (const asset of assetsToCheck) {
        try {
          const response = await this.makeRequest(`${this.baseUrl}${asset}`);
          if (response.success) {
            passedChecks++;
          }
        } catch (error) {
          this.log(`静态资源检查失败 ${asset}: ${error.message}`, 'warning');
        }
      }
      
      return passedChecks >= Math.ceil(assetsToCheck.length * 0.7); // 至少70%的资源可访问
    } catch (error) {
      this.log(`静态资源检查失败: ${error.message}`, 'error');
      return false;
    }
  }

  // 检查 API 端点 (如果存在)
  async checkApiEndpoints() {
    try {
      const apiEndpoints = [
        '/api/health',
        '/api/status',
        '/api/version'
      ];
      
      let availableEndpoints = 0;
      
      for (const endpoint of apiEndpoints) {
        try {
          const response = await this.makeRequest(`${this.baseUrl}${endpoint}`);
          if (response.success) {
            availableEndpoints++;
          }
        } catch (error) {
          // API 端点可能不存在，这是正常的
        }
      }
      
      // 如果有 API 端点，至少有一个可用
      return availableEndpoints > 0;
    } catch (error) {
      this.log(`API 端点检查失败: ${error.message}`, 'warning');
      return true; // API 检查失败不阻塞部署
    }
  }

  // 检查响应时间
  async checkResponseTime() {
    try {
      const startTime = Date.now();
      const response = await this.makeRequest(this.baseUrl);
      const responseTime = Date.now() - startTime;
      
      const maxAcceptableTime = this.environment === 'production' ? 3000 : 5000;
      
      if (responseTime <= maxAcceptableTime) {
        this.log(`响应时间: ${responseTime}ms (阈值: ${maxAcceptableTime}ms)`, 'success');
        return true;
      } else {
        this.log(`响应时间过长: ${responseTime}ms (阈值: ${maxAcceptableTime}ms)`, 'warning');
        return false;
      }
    } catch (error) {
      this.log(`响应时间检查失败: ${error.message}`, 'error');
      return false;
    }
  }

  // 检查页面内容
  async checkPageContent() {
    try {
      const response = await this.makeRequest(this.baseUrl);
      
      if (!response.success) {
        return false;
      }
      
      // 检查关键内容
      const criticalContent = [
        '<!DOCTYPE html>',
        '<html',
        '<head>',
        '<title>',
        'charset='
      ];
      
      const missingContent = criticalContent.filter(content => 
        !response.body.includes(content)
      );
      
      if (missingContent.length === 0) {
        return true;
      } else {
        this.log(`页面内容缺失: ${missingContent.join(', ')}`, 'warning');
        return false;
      }
    } catch (error) {
      this.log(`页面内容检查失败: ${error.message}`, 'error');
      return false;
    }
  }

  // 检查错误页面
  async checkErrorHandling() {
    try {
      // 检查404页面
      const response = await this.makeRequest(`${this.baseUrl}/non-existent-page`);
      
      // 404 应该返回 404 状态码或重定向到主页
      return response.statusCode === 404 || 
             response.statusCode === 200; // SPA 可能返回200并渲染主页
    } catch (error) {
      this.log(`错误处理检查失败: ${error.message}`, 'warning');
      return true; // 错误处理检查失败不阻塞部署
    }
  }

  // 运行浏览器自动化测试 (如果 Playwright 可用)
  async runBrowserTests() {
    try {
      // 检查 Playwright 是否可用
      execSync('npx playwright --version', { stdio: 'ignore' });
      
      // 运行基本浏览器测试
      const testCommand = `npx playwright test --project=chromium --reporter=dot`;
      execSync(testCommand, { stdio: 'pipe' });
      
      this.log('浏览器测试通过', 'success');
      return true;
    } catch (error) {
      this.log('浏览器测试不可用或失败，跳过', 'warning');
      return true; // 浏览器测试失败不阻塞部署
    }
  }

  // 生成验证报告
  generateValidationReport() {
    const report = {
      timestamp: new Date().toISOString(),
      environment: this.environment,
      baseUrl: this.baseUrl,
      results: this.validationResults,
      summary: {
        total: this.validationResults.tests.length,
        passed: this.validationResults.passed,
        failed: this.validationResults.failed,
        warnings: this.validationResults.warnings,
        successRate: this.validationResults.passed / this.validationResults.tests.length * 100
      }
    };
    
    const reportPath = `deployment-validation-${this.environment}-${Date.now()}.json`;
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    this.log(`验证报告已生成: ${reportPath}`, 'success');
    
    return report;
  }

  async initialize() {
    // 添加所有验证测试
    await this.addTest('应用可访问性检查', () => this.checkApplicationAccessibility(), true);
    await this.addTest('健康检查端点检查', () => this.checkHealthEndpoint(), true);
    await this.addTest('静态资源检查', () => this.checkStaticAssets(), true);
    await this.addTest('API 端点检查', () => this.checkApiEndpoints(), false);
    await this.addTest('响应时间检查', () => this.checkResponseTime(), false);
    await this.addTest('页面内容检查', () => this.checkPageContent(), true);
    await this.addTest('错误处理检查', () => this.checkErrorHandling(), false);
    await this.addTest('浏览器测试', () => this.runBrowserTests(), false);
  }
}

// 命令行执行
async function main() {
  const args = process.argv.slice(2);
  const envArg = args.find(arg => arg.startsWith('--env='))?.split('=')[1];
  
  if (envArg) {
    process.env.DEPLOY_ENV = envArg;
  }
  
  const baseUrlArg = args.find(arg => arg.startsWith('--url='))?.split('=')[1];
  if (baseUrlArg) {
    process.env.BASE_URL = baseUrlArg;
  }
  
  const validator = new PostDeployValidator();
  await validator.initialize();
  
  const success = await validator.runAllTests();
  validator.generateValidationReport();
  
  if (success) {
    console.log('\n🎉 部署验证成功！');
  } else {
    console.log('\n❌ 部署验证失败！');
  }
  
  process.exit(success ? 0 : 1);
}

if (require.main === module) {
  main().catch(error => {
    console.error('部署验证失败:', error);
    process.exit(1);
  });
}

module.exports = PostDeployValidator;