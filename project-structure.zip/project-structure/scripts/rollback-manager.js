#!/usr/bin/env node

/**
 * 回滚策略脚本
 * 实现自动回滚机制，支持多种回滚策略
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

class RollbackManager {
  constructor() {
    this.deploymentsDir = 'deployments';
    this.maxRetainedVersions = 5;
    this.rollbackConfig = this.loadRollbackConfig();
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const colors = {
      info: '\x1b[36m',
      success: '\x1b[32m',
      warning: '\x1b[33m',
      error: '\x1b[31m',
      reset: '\x1b[0m'
    };
    
    console.log(`${colors[type]}[${timestamp}] ${message}${colors.reset}`);
  }

  loadRollbackConfig() {
    const configPath = './rollback.config.json';
    if (fs.existsSync(configPath)) {
      return JSON.parse(fs.readFileSync(configPath, 'utf8'));
    }
    
    return {
      strategies: {
        automatic: {
          enabled: true,
          triggers: [
            'health_check_failed',
            'response_time_slow',
            'error_rate_high',
            'deployment_validation_failed'
          ],
          maxRollbackAttempts: 3,
          rollbackTimeout: 300000 // 5 minutes
        },
        manual: {
          confirmationRequired: true,
          confirmationTimeout: 30000 // 30 seconds
        }
      },
      environments: {
        development: {
          autoRollback: true,
          backupRetention: 3
        },
        staging: {
          autoRollback: true,
          backupRetention: 5
        },
        production: {
          autoRollback: false,
          backupRetention: 10
        }
      }
    };
  }

  // 获取部署历史记录
  getDeploymentHistory() {
    const recordPath = path.join(this.deploymentsDir, 'deployment-records.json');
    
    if (!fs.existsSync(recordPath)) {
      return [];
    }
    
    try {
      const records = JSON.parse(fs.readFileSync(recordPath, 'utf8'));
      return records.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    } catch (error) {
      this.log(`读取部署记录失败: ${error.message}`, 'error');
      return [];
    }
  }

  // 查找可回滚的版本
  findRollbackCandidates(environment, limit = 3) {
    const history = this.getDeploymentHistory();
    const envHistory = history.filter(record => 
      record.environment === environment && 
      record.status === 'deployed'
    );
    
    return envHistory.slice(1, limit + 1); // 排除当前版本，获取之前的版本
  }

  // 验证回滚候选版本
  validateRollbackCandidate(candidate) {
    if (!candidate.backupDir || !fs.existsSync(candidate.backupDir)) {
      throw new Error(`备份目录不存在: ${candidate.backupDir}`);
    }
    
    // 检查备份文件的完整性
    const backupPath = candidate.backupDir;
    const requiredFiles = ['index.html'];
    const missingFiles = requiredFiles.filter(file => {
      const filePath = path.join(backupPath, file);
      return !fs.existsSync(filePath);
    });
    
    if (missingFiles.length > 0) {
      throw new Error(`备份文件不完整，缺少: ${missingFiles.join(', ')}`);
    }
    
    return true;
  }

  // 创建当前版本的备份
  createCurrentBackup(environment) {
    const envConfig = this.getEnvironmentConfig(environment);
    const backupDir = path.join(this.deploymentsDir, `current-backup-${Date.now()}`);
    
    if (fs.existsSync(envConfig.deployPath)) {
      this.copyDirectory(envConfig.deployPath, backupDir);
      this.log(`已创建当前版本备份: ${backupDir}`, 'success');
      return backupDir;
    }
    
    return null;
  }

  getEnvironmentConfig(environment) {
    const configPath = './deployment.config.json';
    if (fs.existsSync(configPath)) {
      const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      return config.environments[environment];
    }
    
    throw new Error(`环境配置不存在: ${environment}`);
  }

  copyDirectory(src, dest) {
    if (!fs.existsSync(src)) {
      return;
    }
    
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    
    const items = fs.readdirSync(src);
    items.forEach(item => {
      const srcPath = path.join(src, item);
      const destPath = path.join(dest, item);
      
      const stat = fs.statSync(srcPath);
      if (stat.isDirectory()) {
        this.copyDirectory(srcPath, destPath);
      } else {
        fs.copyFileSync(srcPath, destPath);
      }
    });
  }

  // 执行回滚
  async performRollback(environment, targetVersion = null, options = {}) {
    this.log(`开始回滚 ${environment} 环境...`);
    
    try {
      // 获取回滚候选版本
      const candidates = this.findRollbackCandidates(environment, 3);
      
      if (candidates.length === 0) {
        throw new Error('没有找到可回滚的版本');
      }
      
      let rollbackTarget = targetVersion 
        ? candidates.find(c => c.id === targetVersion)
        : candidates[0]; // 默认回滚到上一个版本
      
      if (!rollbackTarget) {
        throw new Error(`未找到目标回滚版本: ${targetVersion}`);
      }
      
      // 验证回滚目标
      this.validateRollbackCandidate(rollbackTarget);
      
      // 创建当前版本备份
      const currentBackup = this.createCurrentBackup(environment);
      
      // 执行回滚
      const success = await this.executeRollback(environment, rollbackTarget, options);
      
      if (success) {
        // 记录回滚操作
        this.recordRollback(environment, rollbackTarget, currentBackup);
        
        // 执行回滚后验证
        const validationSuccess = await this.validateRollback(environment);
        
        if (validationSuccess) {
          this.log(`回滚成功到版本: ${rollbackTarget.id}`, 'success');
          return true;
        } else {
          this.log('回滚验证失败，考虑重新回滚', 'warning');
          return false;
        }
      } else {
        throw new Error('回滚执行失败');
      }
      
    } catch (error) {
      this.log(`回滚失败: ${error.message}`, 'error');
      
      if (options.retryOnFailure && options.retryAttempts < 3) {
        this.log(`尝试重新回滚... (尝试 ${options.retryAttempts + 1}/3)`, 'warning');
        return await this.performRollback(environment, targetVersion, {
          ...options,
          retryAttempts: (options.retryAttempts || 0) + 1
        });
      }
      
      return false;
    }
  }

  async executeRollback(environment, targetVersion, options = {}) {
    this.log(`执行回滚到版本: ${targetVersion.id}`);
    
    try {
      const envConfig = this.getEnvironmentConfig(environment);
      
      // 停止相关服务 (如果适用)
      if (options.stopServices) {
        await this.stopServices(environment);
      }
      
      // 恢复备份
      this.copyDirectory(targetVersion.backupDir, envConfig.deployPath);
      
      // 重新启动服务
      if (options.restartServices) {
        await this.restartServices(environment);
      }
      
      // 等待服务启动
      if (options.waitForStartup) {
        await this.waitForStartup(environment, options.startupTimeout || 30000);
      }
      
      return true;
    } catch (error) {
      this.log(`回滚执行失败: ${error.message}`, 'error');
      return false;
    }
  }

  async stopServices(environment) {
    this.log(`停止 ${environment} 环境服务...`);
    // 实现服务停止逻辑
    // 例如: docker-compose down, systemctl stop, etc.
  }

  async restartServices(environment) {
    this.log(`重启 ${environment} 环境服务...`);
    // 实现服务重启逻辑
    // 例如: docker-compose up -d, systemctl start, etc.
  }

  async waitForStartup(environment, timeout) {
    this.log(`等待 ${environment} 环境启动...`);
    
    const healthUrl = this.getEnvironmentConfig(environment).healthCheckUrl;
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
      try {
        const response = await this.makeHealthCheckRequest(healthUrl);
        if (response && response.statusCode === 200) {
          this.log('服务启动成功', 'success');
          return true;
        }
      } catch (error) {
        // 继续等待
      }
      
      await this.sleep(2000);
    }
    
    throw new Error('服务启动超时');
  }

  makeHealthCheckRequest(url) {
    return new Promise((resolve, reject) => {
      const http = require('http');
      const req = http.get(url, (res) => {
        resolve(res);
      });
      
      req.on('error', reject);
      req.setTimeout(10000, () => {
        req.destroy();
        reject(new Error('健康检查超时'));
      });
    });
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // 回滚后验证
  async validateRollback(environment) {
    this.log(`验证回滚结果: ${environment}`);
    
    try {
      // 运行部署后验证脚本
      const validationScript = './post-deploy-validate.js';
      if (fs.existsSync(validationScript)) {
        execSync(`node ${validationScript} --env=${environment}`, { 
          stdio: 'pipe' 
        });
        return true;
      }
      
      // 简单的健康检查
      const healthUrl = this.getEnvironmentConfig(environment).healthCheckUrl;
      const response = await this.makeHealthCheckRequest(healthUrl);
      
      return response.statusCode === 200;
    } catch (error) {
      this.log(`回滚验证失败: ${error.message}`, 'error');
      return false;
    }
  }

  // 记录回滚操作
  recordRollback(environment, targetVersion, currentBackup) {
    const recordPath = path.join(this.deploymentsDir, 'rollback-records.json');
    let records = [];
    
    if (fs.existsSync(recordPath)) {
      records = JSON.parse(fs.readFileSync(recordPath, 'utf8'));
    }
    
    const rollbackRecord = {
      id: `rollback-${Date.now()}`,
      environment,
      targetVersion: targetVersion.id,
      targetTimestamp: targetVersion.timestamp,
      currentBackup: currentBackup,
      timestamp: new Date().toISOString(),
      status: 'completed'
    };
    
    records.push(rollbackRecord);
    
    // 清理旧记录
    if (records.length > 50) {
      records = records.slice(-50);
    }
    
    fs.writeFileSync(recordPath, JSON.stringify(records, null, 2));
    this.log(`回滚记录已保存: ${rollbackRecord.id}`, 'success');
  }

  // 自动回滚触发器
  async triggerAutomaticRollback(environment, reason, metadata = {}) {
    const envConfig = this.rollbackConfig.environments[environment];
    
    if (!envConfig || !envConfig.autoRollback) {
      this.log(`环境 ${environment} 未启用自动回滚`, 'info');
      return false;
    }
    
    this.log(`触发自动回滚: ${reason}`, 'warning');
    
    return await this.performRollback(environment, null, {
      retryOnFailure: true,
      stopServices: true,
      restartServices: true,
      waitForStartup: true,
      metadata: { reason, ...metadata }
    });
  }

  // 列出可用的回滚版本
  listAvailableRollbacks(environment) {
    const candidates = this.findRollbackCandidates(environment, 10);
    
    console.log(`\n可用的回滚版本 (${environment}):`);
    console.log('='.repeat(60));
    
    candidates.forEach((candidate, index) => {
      console.log(`${index + 1}. 版本 ID: ${candidate.id}`);
      console.log(`   时间: ${candidate.timestamp}`);
      console.log(`   备份: ${candidate.backupDir}`);
      console.log(`   状态: ${candidate.status}`);
      console.log('-'.repeat(40));
    });
    
    return candidates;
  }

  // 清理旧版本
  cleanupOldVersions(environment) {
    const envConfig = this.rollbackConfig.environments[environment];
    const retentionCount = envConfig ? envConfig.backupRetention : this.maxRetainedVersions;
    
    const history = this.getDeploymentHistory();
    const envHistory = history.filter(record => record.environment === environment);
    
    if (envHistory.length <= retentionCount) {
      this.log(`无需清理，当前版本数量在保留限制内`, 'info');
      return;
    }
    
    const versionsToRemove = envHistory.slice(retentionCount);
    
    versionsToRemove.forEach(version => {
      if (version.backupDir && fs.existsSync(version.backupDir)) {
        fs.rmSync(version.backupDir, { recursive: true, force: true });
        this.log(`已清理旧版本: ${version.id}`, 'info');
      }
    });
    
    this.log(`清理完成，移除了 ${versionsToRemove.length} 个旧版本`, 'success');
  }
}

// 命令行执行
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  const environment = args.find(arg => arg.startsWith('--env='))?.split('=')[1];
  
  const rollbackManager = new RollbackManager();
  
  switch (command) {
    case 'rollback':
      if (!environment) {
        console.error('请指定环境: --env=environment');
        process.exit(1);
      }
      
      const targetVersion = args.find(arg => arg.startsWith('--version='))?.split('=')[1];
      const success = await rollbackManager.performRollback(environment, targetVersion);
      process.exit(success ? 0 : 1);
      break;
      
    case 'list':
      if (!environment) {
        console.error('请指定环境: --env=environment');
        process.exit(1);
      }
      
      rollbackManager.listAvailableRollbacks(environment);
      break;
      
    case 'cleanup':
      if (!environment) {
        console.error('请指定环境: --env=environment');
        process.exit(1);
      }
      
      rollbackManager.cleanupOldVersions(environment);
      break;
      
    default:
      console.log(`
用法:
  node rollback-manager.js rollback --env=environment [--version=version-id]
  node rollback-manager.js list --env=environment
  node rollback-manager.js cleanup --env=environment

示例:
  node rollback-manager.js rollback --env=production
  node rollback-manager.js rollback --env=staging --version=deploy-2024-01-01-12-00-00
  node rollback-manager.js list --env=production
  node rollback-manager.js cleanup --env=production
      `);
      process.exit(1);
  }
}

if (require.main === module) {
  main().catch(error => {
    console.error('回滚管理失败:', error);
    process.exit(1);
  });
}

module.exports = RollbackManager;