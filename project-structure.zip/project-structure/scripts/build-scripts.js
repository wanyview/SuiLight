#!/usr/bin/env node

/**
 * 构建脚本 - 统一的构建流程
 * 用于构建项目的各个环境版本
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

class BuildManager {
  constructor() {
    this.env = process.env.NODE_ENV || 'development';
    this.timestamp = new Date().toISOString();
    this.buildDir = 'dist';
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const colors = {
      info: '\x1b[36m',
      success: '\x1b[32m',
      warning: '\x1b[33m',
      error: '\x1b[31m',
      reset: '\x1b[0m'
    };
    
    console.log(`${colors[type]}[${timestamp}] ${message}${colors.reset}`);
  }

  checkPrerequisites() {
    this.log('检查构建先决条件...');
    
    const requiredFiles = ['package.json', 'vite.config.ts', 'tsconfig.json'];
    const missingFiles = requiredFiles.filter(file => !fs.existsSync(file));
    
    if (missingFiles.length > 0) {
      throw new Error(`缺少必要文件: ${missingFiles.join(', ')}`);
    }

    // 检查Node.js版本
    const nodeVersion = process.version;
    const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);
    if (majorVersion < 16) {
      throw new Error(`Node.js版本过低，当前版本: ${nodeVersion}，要求: >=16.0.0`);
    }

    this.log('先决条件检查通过', 'success');
  }

  clean() {
    this.log('清理构建目录...');
    try {
      if (fs.existsSync(this.buildDir)) {
        fs.rmSync(this.buildDir, { recursive: true, force: true });
        this.log('构建目录已清理', 'success');
      }
    } catch (error) {
      this.log(`清理失败: ${error.message}`, 'error');
    }
  }

  installDependencies() {
    this.log('安装依赖包...');
    try {
      execSync('pnpm install --prefer-offline', { 
        stdio: 'inherit',
        env: { ...process.env, FORCE_COLOR: '1' }
      });
      this.log('依赖包安装完成', 'success');
    } catch (error) {
      throw new Error('依赖包安装失败');
    }
  }

  runTests() {
    this.log('运行测试...');
    try {
      execSync('pnpm test --passWithNoTests', { 
        stdio: 'inherit',
        env: { ...process.env, FORCE_COLOR: '1' }
      });
      this.log('测试通过', 'success');
    } catch (error) {
      this.log('测试失败', 'warning');
      // 在开发环境中可以继续构建，生产环境需要通过测试
      if (this.env === 'production') {
        throw new Error('生产环境构建必须通过所有测试');
      }
    }
  }

  lint() {
    this.log('代码检查...');
    try {
      execSync('pnpm lint', { 
        stdio: 'inherit',
        env: { ...process.env, FORCE_COLOR: '1' }
      });
      this.log('代码检查通过', 'success');
    } catch (error) {
      this.log('代码检查失败', 'warning');
      if (this.env === 'production') {
        throw new Error('生产环境构建必须通过代码检查');
      }
    }
  }

  build() {
    this.log(`开始构建 ${this.env} 版本...`);
    
    const buildCommand = this.env === 'production' 
      ? 'pnpm build:prod'
      : 'pnpm build';

    try {
      execSync(buildCommand, { 
        stdio: 'inherit',
        env: { 
          ...process.env, 
          FORCE_COLOR: '1',
          BUILD_ENV: this.env,
          BUILD_TIMESTAMP: this.timestamp
        }
      });
      this.log('构建完成', 'success');
    } catch (error) {
      throw new Error(`构建失败: ${error.message}`);
    }
  }

  generateBuildInfo() {
    const buildInfo = {
      buildTime: this.timestamp,
      environment: this.env,
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch,
      gitCommit: this.getGitCommit(),
      buildNumber: process.env.BUILD_NUMBER || 'local'
    };

    const buildInfoPath = path.join(this.buildDir, 'build-info.json');
    fs.writeFileSync(buildInfoPath, JSON.stringify(buildInfo, null, 2));
    this.log('构建信息已生成', 'success');
  }

  getGitCommit() {
    try {
      return execSync('git rev-parse --short HEAD').toString().trim();
    } catch {
      return 'unknown';
    }
  }

  validateBuild() {
    this.log('验证构建结果...');
    
    if (!fs.existsSync(this.buildDir)) {
      throw new Error('构建目录不存在');
    }

    const requiredFiles = ['index.html', 'assets'];
    const missingFiles = requiredFiles.filter(file => {
      const filePath = path.join(this.buildDir, file);
      return !fs.existsSync(filePath);
    });

    if (missingFiles.length > 0) {
      throw new Error(`构建文件缺失: ${missingFiles.join(', ')}`);
    }

    this.log('构建验证通过', 'success');
  }

  async buildAll() {
    try {
      this.checkPrerequisites();
      this.clean();
      this.installDependencies();
      this.runTests();
      this.lint();
      this.build();
      this.generateBuildInfo();
      this.validateBuild();

      this.log(`🎉 ${this.env} 环境构建成功！`, 'success');
      return true;
    } catch (error) {
      this.log(`构建失败: ${error.message}`, 'error');
      process.exit(1);
    }
  }
}

// 命令行参数解析
const args = process.argv.slice(2);
const env = args.find(arg => arg.startsWith('--env='))?.split('=')[1] || process.env.NODE_ENV || 'development';

if (require.main === module) {
  const builder = new BuildManager();
  builder.env = env;
  builder.buildAll();
}

module.exports = BuildManager;