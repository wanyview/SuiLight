#!/usr/bin/env node

/**
 * 统一构建部署脚本
 * 提供一键构建、部署、验证的完整流程
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

class UnifiedDeployment {
  constructor() {
    this.scripts = {
      build: './build-scripts.js',
      deploy: './deploy-scripts.js',
      validate: './post-deploy-validate.js',
      rollback: './rollback-manager.js',
      environment: './environment-check.js',
      monitoring: './monitoring-setup.js'
    };
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const colors = {
      info: '\x1b[36m',
      success: '\x1b[32m',
      warning: '\x1b[33m',
      error: '\x1b[31m',
      reset: '\x1b[0m'
    };
    
    console.log(`${colors[type]}[${timestamp}] ${message}${colors.reset}`);
  }

  // 检查脚本是否存在
  checkScript(scriptPath) {
    if (!fs.existsSync(scriptPath)) {
      throw new Error(`脚本文件不存在: ${scriptPath}`);
    }
  }

  // 运行脚本
  runScript(scriptPath, args = []) {
    this.checkScript(scriptPath);
    
    const fullCommand = `node "${scriptPath}" ${args.join(' ')}`;
    this.log(`执行: ${fullCommand}`, 'info');
    
    try {
      execSync(fullCommand, { 
        stdio: 'inherit',
        env: { ...process.env, FORCE_COLOR: '1' }
      });
      return true;
    } catch (error) {
      this.log(`脚本执行失败: ${error.message}`, 'error');
      return false;
    }
  }

  // 环境检查
  async checkEnvironment(environment = 'development') {
    this.log('🔍 检查环境...', 'info');
    const success = this.runScript(this.scripts.environment);
    return success;
  }

  // 构建
  async build(environment = 'development') {
    this.log(`🔨 构建 ${environment} 环境...`, 'info');
    const success = this.runScript(this.scripts.build, [`--env=${environment}`]);
    return success;
  }

  // 部署
  async deploy(environment = 'development') {
    this.log(`🚀 部署到 ${environment} 环境...`, 'info');
    const success = this.runScript(this.scripts.deploy, [`--env=${environment}`]);
    return success;
  }

  // 验证部署
  async validate(environment = 'development', baseUrl = null) {
    this.log(`✅ 验证部署: ${environment}`, 'info');
    const args = [`--env=${environment}`];
    if (baseUrl) {
      args.push(`--url=${baseUrl}`);
    }
    const success = this.runScript(this.scripts.validate, args);
    return success;
  }

  // 回滚
  async rollback(environment, version = null) {
    this.log(`↩️  回滚 ${environment} 环境...`, 'info');
    const args = ['rollback', `--env=${environment}`];
    if (version) {
      args.push(`--version=${version}`);
    }
    const success = this.runScript(this.scripts.rollback, args);
    return success;
  }

  // 列出回滚版本
  listRollbacks(environment) {
    this.log(`📋 列出 ${environment} 环境可回滚版本...`, 'info');
    this.runScript(this.scripts.rollback, ['list', `--env=${environment}`]);
  }

  // 清理旧版本
  cleanup(environment) {
    this.log(`🧹 清理 ${environment} 环境旧版本...`, 'info');
    this.runScript(this.scripts.rollback, ['cleanup', `--env=${environment}`]);
  }

  // 初始化监控
  async initMonitoring() {
    this.log('📊 初始化监控配置...', 'info');
    const success = this.runScript(this.scripts.monitoring, ['init']);
    return success;
  }

  // 启动监控
  async startMonitoring() {
    this.log('📈 启动监控服务...', 'info');
    const success = this.runScript(this.scripts.monitoring, ['start']);
    return success;
  }

  // 完整部署流程
  async fullDeploy(environment = 'development', options = {}) {
    this.log(`🎯 开始完整部署流程: ${environment}`, 'info');
    
    const steps = [
      { name: '环境检查', fn: () => this.checkEnvironment(environment) },
      { name: '构建', fn: () => this.build(environment) },
      { name: '部署', fn: () => this.deploy(environment) },
      { name: '验证部署', fn: () => this.validate(environment, options.baseUrl) }
    ];

    let currentStep = 0;
    
    try {
      for (const step of steps) {
        currentStep++;
        this.log(`📍 执行步骤 ${currentStep}/${steps.length}: ${step.name}`, 'info');
        
        const success = await step.fn();
        
        if (!success) {
          throw new Error(`${step.name} 失败`);
        }
        
        this.log(`✅ ${step.name} 完成`, 'success');
      }
      
      this.log('🎉 完整部署流程成功完成！', 'success');
      return true;
      
    } catch (error) {
      this.log(`❌ 部署流程失败: ${error.message}`, 'error');
      
      if (options.autoRollback !== false) {
        this.log('🔄 触发自动回滚...', 'warning');
        await this.rollback(environment);
      }
      
      return false;
    }
  }

  // 显示帮助信息
  showHelp() {
    console.log(`
🚀 统一构建部署脚本

用法:
  node deploy.js <command> [options]

命令:
  full-deploy [options]     完整部署流程
  build [environment]       构建应用
  deploy [environment]      部署应用
  validate [environment]    验证部署
  rollback [environment]    回滚应用
  list-rollbacks [environment]  列出可回滚版本
  cleanup [environment]     清理旧版本
  init-monitoring          初始化监控
  start-monitoring         启动监控
  check-env [environment]   检查环境
  help                     显示帮助信息

选项:
  --env=environment        指定环境 (development|staging|production)
  --url=baseUrl           指定验证URL
  --no-auto-rollback      禁用自动回滚

示例:
  # 完整部署到开发环境
  node deploy.js full-deploy --env=development
  
  # 构建并部署到生产环境
  node deploy.js build --env=production
  node deploy.js deploy --env=production
  
  # 验证部署
  node deploy.js validate --env=staging --url=https://staging.example.com
  
  # 回滚到上一个版本
  node deploy.js rollback --env=production
  
  # 列出可回滚版本
  node deploy.js list-rollbacks --env=production
  
  # 初始化监控
  node deploy.js init-monitoring
  
  # 启动监控服务
  node deploy.js start-monitoring
    `);
  }
}

// 主函数
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  if (!command || command === 'help') {
    const deployer = new UnifiedDeployment();
    deployer.showHelp();
    process.exit(0);
  }
  
  const deployer = new UnifiedDeployment();
  
  try {
    switch (command) {
      case 'full-deploy':
        {
          const envIndex = args.indexOf('--env');
          const urlIndex = args.indexOf('--url');
          const noRollbackIndex = args.indexOf('--no-auto-rollback');
          
          const environment = envIndex !== -1 ? args[envIndex + 1] : 'development';
          const baseUrl = urlIndex !== -1 ? args[urlIndex + 1] : null;
          const autoRollback = noRollbackIndex === -1;
          
          await deployer.fullDeploy(environment, { baseUrl, autoRollback });
        }
        break;
        
      case 'build':
        {
          const envIndex = args.indexOf('--env');
          const environment = envIndex !== -1 ? args[envIndex + 1] : 'development';
          await deployer.build(environment);
        }
        break;
        
      case 'deploy':
        {
          const envIndex = args.indexOf('--env');
          const environment = envIndex !== -1 ? args[envIndex + 1] : 'development';
          await deployer.deploy(environment);
        }
        break;
        
      case 'validate':
        {
          const envIndex = args.indexOf('--env');
          const urlIndex = args.indexOf('--url');
          const environment = envIndex !== -1 ? args[envIndex + 1] : 'development';
          const baseUrl = urlIndex !== -1 ? args[urlIndex + 1] : null;
          await deployer.validate(environment, baseUrl);
        }
        break;
        
      case 'rollback':
        {
          const envIndex = args.indexOf('--env');
          const versionIndex = args.indexOf('--version');
          const environment = envIndex !== -1 ? args[envIndex + 1] : 'development';
          const version = versionIndex !== -1 ? args[versionIndex + 1] : null;
          await deployer.rollback(environment, version);
        }
        break;
        
      case 'list-rollbacks':
        {
          const envIndex = args.indexOf('--env');
          const environment = envIndex !== -1 ? args[envIndex + 1] : 'development';
          deployer.listRollbacks(environment);
        }
        break;
        
      case 'cleanup':
        {
          const envIndex = args.indexOf('--env');
          const environment = envIndex !== -1 ? args[envIndex + 1] : 'development';
          deployer.cleanup(environment);
        }
        break;
        
      case 'init-monitoring':
        await deployer.initMonitoring();
        break;
        
      case 'start-monitoring':
        await deployer.startMonitoring();
        break;
        
      case 'check-env':
        {
          const envIndex = args.indexOf('--env');
          const environment = envIndex !== -1 ? args[envIndex + 1] : 'development';
          await deployer.checkEnvironment(environment);
        }
        break;
        
      default:
        deployer.showHelp();
        process.exit(1);
    }
    
    process.exit(0);
    
  } catch (error) {
    deployer.log(`执行失败: ${error.message}`, 'error');
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = UnifiedDeployment;