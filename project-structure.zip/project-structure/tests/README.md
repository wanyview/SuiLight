# tests/ 测试文件目录

此目录包含项目的所有测试文件，确保代码质量和功能正确性。

## 测试类型

### 单元测试 (unit/)
测试单个函数、组件或模块的功能
```bash
unit/
├── components/            # 组件测试
├── utils/                 # 工具函数测试
├── hooks/                 # 自定义Hooks测试
└── services/              # 服务测试
```

### 集成测试 (integration/)
测试多个模块之间的交互
```bash
integration/
├── api/                   # API集成测试
├── components/            # 组件集成测试
└── workflows/             # 工作流测试
```

### 端到端测试 (e2e/)
测试完整的用户流程
```bash
e2e/
├── scenarios/             # 用户场景测试
├── fixtures/              # 测试数据
└── utils/                 # E2E测试工具
```

### 性能测试 (performance/)
测试应用性能
```bash
performance/
├── load/                  # 负载测试
├── stress/                # 压力测试
└── metrics/               # 性能指标
```

## 测试配置

### Jest配置示例
```javascript
// jest.config.js
module.exports = {
  testEnvironment: 'jsdom',
  setupFilesAfterEnv: ['<rootDir>/tests/setup.js'],
  testMatch: [
    '<rootDir>/tests/unit/**/*.test.{js,jsx,ts,tsx}',
    '<rootDir>/src/**/*.test.{js,jsx,ts,tsx}'
  ],
  moduleNameMapping: {
    '^@/(.*)$': '<rootDir>/src/$1'
  },
  collectCoverageFrom: [
    'src/**/*.{js,jsx,ts,tsx}',
    '!src/**/*.d.ts',
    '!src/index.tsx'
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80
    }
  }
};
```

### Cypress配置示例
```javascript
// cypress.config.js
const { defineConfig } = require('cypress');

module.exports = defineConfig({
  e2e: {
    baseUrl: 'http://localhost:3000',
    supportFile: 'tests/e2e/support/e2e.js',
    specPattern: 'tests/e2e/specs/**/*.cy.{js,jsx,ts,tsx}',
    viewportWidth: 1280,
    viewportHeight: 720,
    video: false,
    screenshotOnRunFailure: true
  }
});
```

## 测试编写规范

### 单元测试示例
```typescript
// tests/unit/utils/calculator.test.ts
import { Calculator } from '../../../src/utils/calculator';

describe('Calculator', () => {
  let calculator: Calculator;

  beforeEach(() => {
    calculator = new Calculator();
  });

  describe('add', () => {
    it('应该正确计算两个正数的和', () => {
      expect(calculator.add(2, 3)).toBe(5);
    });

    it('应该处理负数', () => {
      expect(calculator.add(-1, 3)).toBe(2);
    });

    it('应该处理小数', () => {
      expect(calculator.add(0.1, 0.2)).toBeCloseTo(0.3);
    });
  });

  describe('divide', () => {
    it('应该正确计算除法', () => {
      expect(calculator.divide(6, 2)).toBe(3);
    });

    it('应该抛出除零错误', () => {
      expect(() => calculator.divide(1, 0)).toThrow('Division by zero');
    });
  });
});
```

### 组件测试示例
```typescript
// tests/unit/components/Button.test.tsx
import { render, screen, fireEvent } from '@testing-library/react';
import { Button } from '../../../src/components/Button';

describe('Button Component', () => {
  it('应该渲染按钮文本', () => {
    render(<Button>点击我</Button>);
    expect(screen.getByText('点击我')).toBeInTheDocument();
  });

  it('应该在点击时调用回调函数', () => {
    const handleClick = jest.fn();
    render(<Button onClick={handleClick}>点击我</Button>);
    
    fireEvent.click(screen.getByText('点击我'));
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('应该在禁用状态下不响应点击', () => {
    const handleClick = jest.fn();
    render(
      <Button onClick={handleClick} disabled>
        禁用按钮
      </Button>
    );
    
    fireEvent.click(screen.getByText('禁用按钮'));
    expect(handleClick).not.toHaveBeenCalled();
  });

  it('应该应用正确的CSS类', () => {
    render(<Button variant="primary">主要按钮</Button>);
    expect(screen.getByText('主要按钮')).toHaveClass('btn-primary');
  });
});
```

### API测试示例
```typescript
// tests/integration/api/user.test.ts
import request from 'supertest';
import app from '../../../src/app';

describe('User API', () => {
  describe('GET /api/users/:id', () => {
    it('应该返回用户信息', async () => {
      const response = await request(app)
        .get('/api/users/1')
        .expect(200);

      expect(response.body).toMatchObject({
        id: 1,
        name: expect.any(String),
        email: expect.any(String)
      });
    });

    it('应该返回404当用户不存在时', async () => {
      await request(app)
        .get('/api/users/999')
        .expect(404);
    });
  });

  describe('POST /api/users', () => {
    it('应该创建新用户', async () => {
      const userData = {
        name: '测试用户',
        email: 'test@example.com'
      };

      const response = await request(app)
        .post('/api/users')
        .send(userData)
        .expect(201);

      expect(response.body).toMatchObject({
        id: expect.any(Number),
        ...userData
      });
    });

    it('应该在缺少必填字段时返回400', async () => {
      await request(app)
        .post('/api/users')
        .send({ name: '缺少邮箱' })
        .expect(400);
    });
  });
});
```

### E2E测试示例
```typescript
// tests/e2e/specs/user-flow.cy.ts
describe('用户注册流程', () => {
  it('用户应该能够成功注册', () => {
    cy.visit('/register');
    
    // 填写注册表单
    cy.get('[data-testid="name-input"]').type('测试用户');
    cy.get('[data-testid="email-input"]').type('test@example.com');
    cy.get('[data-testid="password-input"]').type('password123');
    
    // 提交表单
    cy.get('[data-testid="submit-button"]').click();
    
    // 验证注册成功
    cy.url().should('include', '/dashboard');
    cy.contains('欢迎，测试用户').should('be.visible');
  });

  it('用户应该看到注册错误信息', () => {
    cy.visit('/register');
    
    // 提交空表单
    cy.get('[data-testid="submit-button"]').click();
    
    // 验证错误信息
    cy.contains('请输入姓名').should('be.visible');
    cy.contains('请输入邮箱').should('be.visible');
    cy.contains('请输入密码').should('be.visible');
  });
});
```

## 测试工具和库

### 单元测试工具
- **Jest** - JavaScript测试框架
- **React Testing Library** - React组件测试
- **Vitest** - 快速单元测试框架

### 集成测试工具
- **Supertest** - HTTP API测试
- **MSW** - API模拟
- **Testcontainers** - 数据库测试

### E2E测试工具
- **Cypress** - 端到端测试框架
- **Playwright** - 现代Web测试
- **Selenium** - 传统Web自动化

### 性能测试工具
- **Lighthouse** - 性能分析
- **WebPageTest** - 页面性能测试
- **k6** - 负载测试

## 测试最佳实践

### 测试结构
- 使用AAA模式（Arrange-Act-Assert）
- 每个测试只验证一个功能
- 使用描述性的测试名称
- 保持测试简单和专注

### 测试数据
- 使用工厂模式创建测试数据
- 避免测试间的依赖
- 使用夹具（fixtures）管理共享数据
- 清理测试数据

### 模拟和存根
- 模拟外部依赖
- 使用 spies 监控函数调用
- 模拟异步操作
- 控制时间相关测试

### 测试性能
- 并行运行测试
- 使用测试缓存
- 避免不必要的等待
- 优化测试设置

### CI/CD集成
```yaml
# .github/workflows/test.yml
name: Test
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Run unit tests
        run: npm run test:unit
      
      - name: Run integration tests
        run: npm run test:integration
      
      - name: Run E2E tests
        run: npm run test:e2e
      
      - name: Upload coverage
        uses: codecov/codecov-action@v3
```

### 测试覆盖率
- 设置覆盖率阈值
- 关注关键路径覆盖率
- 避免为简单getter/setter写测试
- 平衡覆盖率和测试价值

### 调试测试
- 使用VS Code调试器
- 查看详细的测试输出
- 使用测试专用日志
- 隔离失败的测试