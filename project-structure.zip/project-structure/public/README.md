# public/ 静态资源目录

此目录包含项目的静态资源文件，这些文件将直接部署到Web服务器。

## 目录结构建议

```
public/
├── favicon.ico         # 网站图标
├── robots.txt          # 搜索引擎爬虫配置
├── sitemap.xml         # 网站地图
├── manifest.json       # PWA清单文件
├── sw.js               # Service Worker
├── images/             # 图片资源
│   ├── logo.png        # 项目Logo
│   ├── icons/          # 图标文件
│   └── backgrounds/    # 背景图片
├── fonts/              # 字体文件
│   ├── Inter-Regular.woff2
│   └── Inter-Bold.woff2
├── videos/             # 视频文件
├── audio/              # 音频文件
└── data/               # 静态数据文件
    ├── config.json     # 配置文件
    └── samples/        # 示例数据
```

## 文件组织原则

### 图片资源
- 使用WebP格式以获得更好的压缩效果
- 为不同设备提供不同分辨率的图片
- 使用有意义的文件名
- 添加适当的alt文本

### 字体文件
- 使用现代字体格式（woff2, woff）
- 考虑字体加载性能
- 提供字体回退选项

### 配置文件
- 使用JSON格式存储配置
- 提供配置文件的注释
- 考虑环境特定的配置

## 优化建议

### 图片优化
```html
<!-- 使用现代图片格式 -->
<picture>
  <source srcset="image.webp" type="image/webp">
  <source srcset="image.avif" type="image/avif">
  <img src="image.jpg" alt="描述" loading="lazy">
</picture>
```

### 资源预加载
```html
<!-- 预加载关键资源 -->
<link rel="preload" href="/fonts/main.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/images/hero.jpg" as="image">
```

### 缓存策略
- 设置适当的Cache-Control头部
- 使用文件名哈希实现缓存更新
- 考虑CDN缓存策略

## PWA支持

如需支持渐进式Web应用（PWA），请包含：

1. **manifest.json** - 应用清单文件
2. **sw.js** - Service Worker文件
3. **图标文件** - 不同尺寸的应用图标

## 安全性考虑

- 确保静态资源的安全访问
- 避免在静态资源中包含敏感信息
- 使用HTTPS服务静态资源
- 设置适当的CSP（内容安全策略）